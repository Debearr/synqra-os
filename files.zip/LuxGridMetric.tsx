import React from "react";

interface LuxGridMetricProps {
  label: string;
  value: string | number;
  className?: string;
}

export default function LuxGridMetric({ label, value, className = "" }: LuxGridMetricProps) {
  return (
    <div className={`luxgrid-metric ${className}`}>
      <span className="luxgrid-metric-label">{label}</span>
      <span className="luxgrid-metric-value">{value}</span>
    </div>
  );
}
