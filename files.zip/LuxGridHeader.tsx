import React from "react";

interface LuxGridHeaderProps {
  title: string;
  subtitle?: string;
  className?: string;
}

export default function LuxGridHeader({ title, subtitle, className = "" }: LuxGridHeaderProps) {
  return (
    <header className={`luxgrid-header ${className}`}>
      <h1 className="luxgrid-header-title">{title}</h1>
      {subtitle && <p className="luxgrid-header-subtitle">{subtitle}</p>}
    </header>
  );
}
