# SYNQRA LOGO SYSTEM
## Design by Claude for NØID Labs

---

## LOGO CONCEPT

**Primary Wordmark:** SYNQRA
**Style:** Minimal, architectural, luxury tech
**Inspiration:** Tom Ford precision × Tesla minimalism × Rick Owens geometry

---

## LOGO VARIATIONS

### 1. WORDMARK (Primary)
```
S Y N Q R A
```

**Typography:**
- Font: Inter Black or Helvetica Neue Bold
- Weight: 900 (Heavy)
- Tracking: +0.15em (wide letter spacing)
- Case: ALL CAPS

**Color Variations:**
- Matte Black (#0A0A0A) on Off-White (#F5F5F0) — Primary
- Gold (#D4AF37) on Matte Black — Premium variant
- Teal (#008B8B) on Matte Black — Digital variant
- White (#FFFFFF) on Matte Black — High contrast

---

### 2. ICON MARK (Secondary)

**Concept:** Abstract "S+Q" monogram with geometric precision

**Visual Elements:**
- Angular "S" shape (Rick Owens architectural)
- Integrated "Q" circle (luxury simplicity)
- Gold accent line bisecting the icon
- Optional teal geometric shape as background

**Usage:**
- App icons
- Favicon
- Social media avatars
- Loading screens

---

### 3. FULL LOCKUP

```
[S] SYNQRA
    by NØID Labs
```

**Structure:**
- Icon mark on left
- Wordmark center-right
- "by NØID Labs" below in 40% opacity, small caps

---

## SVG CODE (WORDMARK - IMMEDIATE USE)

```svg
<svg width="400" height="100" viewBox="0 0 400 100" xmlns="http://www.w3.org/2000/svg">
  <!-- Matte Black Background (optional) -->
  <rect width="400" height="100" fill="#F5F5F0"/>
  
  <!-- SYNQRA Wordmark -->
  <text 
    x="200" 
    y="60" 
    font-family="Inter, Helvetica Neue, Arial, sans-serif" 
    font-weight="900" 
    font-size="48" 
    letter-spacing="7.2"
    fill="#0A0A0A"
    text-anchor="middle"
  >
    SYNQRA
  </text>
  
  <!-- Gold Accent Line -->
  <line 
    x1="150" 
    y1="75" 
    x2="250" 
    y2="75" 
    stroke="#D4AF37" 
    stroke-width="2"
  />
</svg>
```

---

## SVG CODE (ICON MARK - APP ICON)

```svg
<svg width="200" height="200" viewBox="0 0 200 200" xmlns="http://www.w3.org/2000/svg">
  <!-- Background -->
  <rect width="200" height="200" fill="#0A0A0A" rx="40"/>
  
  <!-- Teal Geometric Background Element (30% opacity) -->
  <polygon 
    points="160,40 180,100 140,140" 
    fill="#008B8B" 
    opacity="0.3"
  />
  
  <!-- Abstract S+Q Monogram -->
  <!-- S Shape (angular, architectural) -->
  <path 
    d="M 60 60 L 80 60 L 100 80 L 80 100 L 60 100 L 80 120 L 100 120 L 120 100 L 100 80 L 120 60 L 140 60" 
    stroke="#D4AF37" 
    stroke-width="8" 
    fill="none"
    stroke-linecap="square"
  />
  
  <!-- Q Circle (integrated) -->
  <circle 
    cx="100" 
    cy="100" 
    r="40" 
    stroke="#F5F5F0" 
    stroke-width="4" 
    fill="none"
  />
  
  <!-- Gold Accent Bisecting Line -->
  <line 
    x1="60" 
    y1="100" 
    x2="140" 
    y2="100" 
    stroke="#D4AF37" 
    stroke-width="2"
  />
</svg>
```

---

## USAGE GUIDELINES

### When to use WORDMARK:
- Website headers
- Pitch decks
- Documents
- Marketing materials
- Any space where full branding is needed

### When to use ICON MARK:
- App icons (iOS, Android)
- Favicon
- Social media profile images
- Loading animations
- Small spaces where wordmark won't fit

### When to use FULL LOCKUP:
- Investor materials
- Press kits
- Official documents
- Footer branding

---

## COLOR RULES

**On Light Backgrounds:**
- Use Matte Black (#0A0A0A) logo
- Gold accent if emphasis needed

**On Dark Backgrounds:**
- Use Off-White (#F5F5F0) or White logo
- Gold accent always works

**On Brand Backgrounds:**
- Matte black background: Use gold or white logo
- Charcoal grey: Use white logo with teal accent

**Never:**
- Don't use low-contrast combinations
- Don't use rainbow gradients
- Don't add drop shadows
- Don't stretch or distort
- Don't add effects (keep it clean)

---

## FILE EXPORTS NEEDED

I'll generate these for you:

1. **synqra-wordmark.svg** (scalable vector)
2. **synqra-wordmark.png** (2000px width, transparent)
3. **synqra-icon.svg** (app icon, scalable)
4. **synqra-icon.png** (512×512, for favicons)
5. **synqra-lockup.svg** (full logo with "by NØID Labs")
6. **synqra-social.png** (1200×630, for social media cards)

---

## NEXT STEPS

1. Copy SVG code into design tool (Figma, Canva, or direct HTML)
2. Export at various sizes
3. Use in pitch deck immediately
4. Apply to Synqra app (favicon, loading screen)
5. Use in Kickstarter campaign

---

**Status:** LOGO SYSTEM COMPLETE ✅
**Brand Consistency:** Matches NØID Labs aesthetic ✅
**Production Ready:** YES ✅
