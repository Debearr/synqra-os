# Railway Deployment Fix for Synqra
# Apply these exact changes to fix the Node 18 issue

## FILE 1: nixpacks.toml (at repo root)
# Replace or create this file

[build]
nodejsVersion = "20"

[start]
cmd = "npm run start"

[variables]
NODE_ENV = "production"

## FILE 2: package.json (at repo root)
# Ensure these scripts exist:

{
  "scripts": {
    "dev": "npm --prefix apps/synqra-mvp run dev",
    "build": "npm --prefix apps/synqra-mvp run build",
    "start": "npm --prefix apps/synqra-mvp run start",
    "deploy": "npm --prefix apps/synqra-mvp run build"
  },
  "engines": {
    "node": "20.x",
    "npm": ">=10.0.0"
  }
}

## FILE 3: apps/synqra-mvp/package.json
# Ensure these scripts:

{
  "scripts": {
    "dev": "next dev",
    "build": "next build",
    "start": "next start -p ${PORT:-8080} --hostname 0.0.0.0",
    "lint": "next lint"
  },
  "engines": {
    "node": "20.x"
  }
}

## FILE 4: apps/synqra-mvp/next.config.js
# Add these settings:

/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,
  swcMinify: true,
  output: 'standalone',
  
  // Important for Railway deployment
  generateEtags: false,
  poweredByHeader: false,
  
  // Ensure proper build
  typescript: {
    ignoreBuildErrors: false,
  },
  eslint: {
    ignoreDuringBuilds: false,
  },
}

module.exports = nextConfig

## FILE 5: Remove these files if they exist (they override nixpacks)
# Delete these:
- .nvmrc
- .node-version  
- railway.json (unless you specifically need custom railway config)

## DEPLOYMENT STEPS:

1. Apply all file changes above
2. Commit:
   git add .
   git commit -m "fix: enforce Node 20 runtime for Railway"
   git push origin main

3. Railway will auto-deploy (watch logs)

4. Verify:
   curl https://synqra.co/api/health
   
   Should return: {"status": "ok"}

5. Test in browser:
   https://synqra.co

## If Railway STILL uses Node 18:

Add this to Railway dashboard:
1. Go to Railway project settings
2. Add environment variable:
   NIXPACKS_NODE_VERSION=20

3. Trigger manual redeploy

## Expected build log output (should see):
✓ Node.js 20.x detected
✓ Installing dependencies with pnpm
✓ Building Next.js app
✓ Starting production server on port 8080

---

STATUS: Ready to apply ✅
ESTIMATED FIX TIME: 5 minutes after applying changes ✅
