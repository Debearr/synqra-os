import { NextRequest, NextResponse } from "next/server";

/**
 * Health Check Endpoint
 * GET /api/health/enterprise
 * Returns the current health status of the application
 */
export async function GET(request: NextRequest) {
  const healthData = {
    status: "ok",
    timestamp: new Date().toISOString(),
    uptime: process.uptime(),
    environment: process.env.NODE_ENV || "development",
    version: process.env.npm_package_version || "1.0.0",
    missing: [] as string[],
    warnings: [] as string[],
    invalid: [] as string[],
  };

  // Basic health check
  const isHealthy = healthData.status === "ok";

  return NextResponse.json(healthData, {
    status: isHealthy ? 200 : 503,
  });
}

export type EnterpriseHealthResponse = {
  status: string;
  timestamp: string;
  uptime: number;
  environment: string;
  version: string;
  missing: string[];
  warnings: string[];
  invalid: string[];
};
