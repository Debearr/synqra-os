# 🚨 RAILWAY DEPLOYMENT FIX — LOCKFILE ERROR

## PROBLEM
Railway build failed because `pnpm-lock.yaml` is outdated.

---

## ✅ IMMEDIATE FIX (2 COMMANDS)

Open your terminal in VS Code (or PowerShell) and run these commands:

### **STEP 1: Navigate to project**
```bash
cd C:\Projects\Synqra\noid-dashboard
```

### **STEP 2: Update lockfile**
```bash
pnpm install --no-frozen-lockfile
```

This will:
- Update pnpm-lock.yaml to match package.json
- Install any missing dependencies
- Take ~30 seconds

### **STEP 3: Commit and push**
```bash
git add pnpm-lock.yaml
git commit -m "fix: update pnpm lockfile for Railway deployment"
git push origin main
```

---

## 🎯 WHAT HAPPENS NEXT

1. Railway detects the new push
2. Build starts again (with correct lockfile)
3. Build succeeds (~3-4 minutes)
4. Site goes live at synqra.co

---

## 🛡️ PREVENTING THIS IN THE FUTURE

Add this to your `.gitignore` to avoid lockfile conflicts:

```
# Don't ignore lockfiles - they should be committed
# But if using multiple package managers, choose ONE:
# package-lock.json (npm)
# yarn.lock (yarn)
# pnpm-lock.yaml (pnpm)
```

**IMPORTANT:** You're using `pnpm` locally but your package.json was set up for `npm`. 

### **PERMANENT FIX: Choose ONE package manager**

**OPTION A: Use pnpm everywhere (Recommended)**
```bash
# Update nixpacks.toml
[build]
nodejsVersion = "20"
cmd = "pnpm install --frozen-lockfile"

[start]
cmd = "pnpm run start"
```

**OPTION B: Use npm everywhere**
```bash
# Delete pnpm-lock.yaml, use package-lock.json
rm pnpm-lock.yaml
npm install
git add package-lock.json
git commit -m "chore: switch to npm lockfile"
git push origin main
```

---

## ⚡ RUN THE FIX NOW

**Copy these 3 commands into your terminal:**

```bash
cd C:\Projects\Synqra\noid-dashboard
pnpm install --no-frozen-lockfile
git add pnpm-lock.yaml && git commit -m "fix: update pnpm lockfile" && git push origin main
```

**Then watch Railway dashboard — build will start in 10-20 seconds.**

---

STATUS: Ready to apply ✅
ESTIMATED TIME: 2 minutes to fix + 4 minutes to deploy = 6 minutes total ✅
