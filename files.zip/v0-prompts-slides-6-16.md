# V0 PROMPTS: SLIDES 6-16 (CONTINUATION)

---

## PROMPT 7: SLIDE 6 - HOW IT WORKS

```
Create a "How It Works" slide with 4-stage horizontal pipeline diagram.

TITLE: "The Four-Stage Pipeline"

VISUAL:
Horizontal flow diagram with 4 connected boxes:

BOX 1 (Charcoal #2B2B2B):
- Title: "Strategy"
- Subtitle: "Brand voice definition"
- Label: "One-time, reusable"
- Size: 200px wide, 150px tall

ARROW (→) Gold, 60px

BOX 2 (Graphite #3C3C3C):
- Title: "Generation"
- Subtitle: "High-volume drafting"
- Label: "Fast, cost-efficient"

ARROW (→) Gold, 60px

BOX 3 (Teal #008B8B):
- Title: "Refinement"
- Subtitle: "Tone polishing"
- Label: "Luxury-grade quality"

ARROW (→) Gold, 60px

BOX 4 (Gold #D4AF37, text in matte black):
- Title: "Audit"
- Subtitle: "Final brand check"
- Label: "Human-level precision"

BULLETS:
- Strategy: Brand voice definition (one-time, reusable)
- Generation: High-volume drafting (fast, cost-efficient)
- Refinement: Tone polishing (luxury-grade quality)
- Audit: Final brand integrity check (human-level precision)

ANIMATION:
- Boxes appear left to right (0.3s delays)
- Arrows draw/extend as boxes appear
- Subtle pulse on each box after appearing
```

---

## PROMPT 8: SLIDE 7 - ECONOMIC ADVANTAGE

```
Create economics slide showing key unit economics metrics.

TITLE: "The Unit Economics"

LAYOUT:
Four large metric callouts in 2×2 grid:

METRIC 1 (Top-Left):
- Number: "$120K-360K"
- Label: "Enterprise ACV"
- Sublabel: "Less than 1 agency hire"
- Color: Gold

METRIC 2 (Top-Right):
- Number: "5:1 to 7:1"
- Label: "LTV:CAC Ratio"
- Sublabel: "Highly scalable"
- Color: Teal

METRIC 3 (Bottom-Left):
- Number: "6-9 months"
- Label: "Payback Period"
- Sublabel: "Fast ROI"
- Color: Charcoal

METRIC 4 (Bottom-Right):
- Number: "$99-299"
- Label: "Creator Tier"
- Sublabel: "Predictable revenue"
- Color: Graphite

STYLE:
- Clean, data-focused
- Large numbers (text-5xl)
- Small labels (text-sm)
- Minimal decoration
- Maximum clarity
```

---

## PROMPT 9: SLIDE 8 - TRACTION

```
Create traction slide with status indicators.

TITLE: "Live, Validated, Growing"

VISUAL:
Three large status indicators:

STATUS 1:
- Badge: "LIVE" (green dot, text-4xl, green/teal)
- Sublabel: "Production deployment"
- Details: "Railway, Supabase, Next.js"

STATUS 2:
- Number: "5"
- Label: "Pilot Accounts"
- Details: "Enterprise validation launching"

STATUS 3:
- Number: "$0.016"
- Label: "Cost Per Item"
- Details: "Consistently hitting target"

BULLETS:
- Production deployment: Railway, Supabase, Next.js (fully live)
- Alpha users: Creators, small brands, luxury prospects
- Pilot program: Launching with 5 target enterprise accounts
- Cost validation: Consistently hitting $0.016/item target

STYLE:
- Status dashboard feel
- Confidence, momentum
- Professional metrics display
```

---

## PROMPT 10: SLIDE 9 - MARKET OPPORTUNITY

```
Create market slide with inverted pyramid (TAM/SAM/SOM funnel).

TITLE: "A $12-15 Billion Market"

VISUAL:
Inverted pyramid with 3 sections:

TOP (Wide):
- Text: "$12-15B"
- Label: "TAM: Global luxury content spend"
- Color: Charcoal, full opacity

MIDDLE:
- Text: "$1.8-2.5B"
- Label: "SAM: AI-ready luxury brands"
- Color: Graphite

BOTTOM (Narrow, highlighted):
- Text: "$30-50M"
- Label: "SOM: Year 3 ARR Target"
- Color: Teal background, white text
- Emphasis: This is your focus

BULLETS:
- TAM: $12-15B (global luxury content spend potentially automated)
- SAM: $1.8-2.5B (AI-ready luxury brands with high content needs)
- SOM: $30-50M ARR by Year 3 (realistic, focused execution)
- Wedge strategy: Dominate luxury niche, then expand
```

---

## PROMPT 11: SLIDE 10 - BUSINESS MODEL

```
Create business model slide with dual revenue streams.

TITLE: "Dual Revenue Streams"

LAYOUT:
Two columns, side-by-side:

LEFT COLUMN (Enterprise):
- Header: "Enterprise" (gold accent on top)
- ACV: "$120K-360K"
- Description: "White-glove service, proprietary training"
- Target: "20+ brands by Year 3"
- Revenue Mix: "80% of total"

RIGHT COLUMN (Creator):
- Header: "Creator" (teal accent on top)
- Pricing: "$99-299/month"
- Description: "Self-serve, validation + cash flow"
- Target: "1,500+ users by Year 3"
- Revenue Mix: "20% of total"

ADDITIONAL:
- Diagnostic consultation: $2,500 fixed fee (center, below columns)

STYLE:
- Clean comparison
- Professional pricing tiers
- Clear value proposition
```

---

## PROMPT 12: SLIDE 11 - COMPETITIVE LANDSCAPE

```
Create 2×2 competitive matrix showing category creation.

TITLE: "Category Creation, Not Competition"

VISUAL:
2×2 Matrix:
- X-axis: Cost (Low → High)
- Y-axis: Quality (Generic → Luxury)

QUADRANT 1 (Bottom-Left):
- Label: "Generic AI"
- Examples: "ChatGPT, Jasper, Copy.ai"
- Status: Greyed out (40% opacity)

QUADRANT 2 (Top-Left): ⭐ SYNQRA POSITION
- Highlight: Gold/Teal circle or badge
- Label: "SYNQRA"
- Position: "Luxury Quality + AI Economics"
- Emphasis: ONLY PLAYER IN THIS QUADRANT

QUADRANT 3 (Bottom-Right):
- Empty/greyed out
- Label: "[No players]"

QUADRANT 4 (Top-Right):
- Label: "Premium Agencies"
- Status: Greyed out (40% opacity)
- Note: "Slow, $500+/item"

BULLETS:
- Generic AI (ChatGPT, Jasper): Fast, cheap, low quality
- Premium agencies: Slow, expensive, high quality
- Synqra: Luxury quality + AI economics (only player in this quadrant)
- Moat: Proprietary orchestration + brand training data
```

---

## PROMPT 13: SLIDE 12 - THE MOAT

```
Create moat slide with four pillar visualization.

TITLE: "Why We Win"

VISUAL:
Four vertical pillars/columns:

PILLAR 1 (Charcoal):
- Icon/Symbol: Connecting nodes
- Label: "Orchestration"
- Height: 200px
- Description: "Proprietary routing logic"

PILLAR 2 (Graphite):
- Icon: Database/lock
- Label: "Data"
- Height: 180px
- Description: "Brand training datasets"

PILLAR 3 (Teal):
- Icon: Network graph
- Label: "Network"
- Height: 220px
- Description: "More brands → better models"

PILLAR 4 (Gold):
- Icon: Clock/rocket
- Label: "Timing"
- Height: 190px
- Description: "First-mover advantage"

BULLETS:
- Proprietary orchestration logic (not model dependency)
- Enterprise brand training datasets (exclusive, proprietary)
- Network effects: More brands → better models → more brands
- Timing: First mover in luxury AI automation category

STYLE:
- Architectural, strong visual
- Four pillars of strength
- Minimal, professional
```

---

## PROMPT 14: SLIDE 13 - ROADMAP

```
Create roadmap slide with horizontal Q1-Q4 timeline.

TITLE: "The Execution Plan"

VISUAL:
Horizontal timeline with 4 milestone boxes:

Q1 2026:
- "Launch Founder Pilot"
- "5 enterprise accounts"
- Color: Charcoal

Q2 2026:
- "Creator tier public launch"
- "AuraFX beta"
- Color: Graphite

Q3 2026:
- "Enterprise expansion"
- "20 accounts, Series A"
- Color: Teal

Q4 2026:
- "Platform integrations"
- "Teams, SharePoint, Shopify"
- Color: Gold

CONNECTING LINE:
- Thin gold line connecting all boxes
- Flows left to right

STYLE:
- Clean timeline
- Professional roadmap
- Achievable milestones
```

---

## PROMPT 15: SLIDE 14 - FOUNDER STORY

```
Create founder story slide with 3-part journey visual.

TITLE: "Built by Someone Who Understands Luxury"

VISUAL:
Three-part horizontal journey:

PART 1 (Left):
- Icon: Luxury items (jewelry, art)
- Text: "10+ Years"
- Label: "Luxury Sales"
- Sublabel: "Bulgari, Cartier, Disney"

ARROW (Gold, 40px) →

PART 2 (Middle):
- Icon: Code symbol or laptop
- Text: "8 Months"
- Label: "Self-Taught Builder"
- Sublabel: "Built entire tech stack solo"

ARROW (Gold, 40px) →

PART 3 (Right):
- Icon: Three overlapping circles (ecosystem)
- Text: "NØID Labs"
- Label: "Luxury Automation"
- Sublabel: "Synqra + NØID + AuraFX"

BULLETS:
- 10+ years: Luxury sales (Bulgari, Cartier, cruise lines)
- Deep expertise: Affluent consumers, brand positioning, premium service
- Self-taught builder: Entire tech stack built solo in <1 year
- Vision: Apple-level simplicity for luxury automation

STYLE:
- Narrative flow
- Authentic, compelling
- Human story, not just metrics
```

---

## PROMPT 16: SLIDE 15 - THE ASK

```
Create "The Ask" slide with pie chart and funding details.

TITLE: "Seeking $2.5M Pre-Seed Round"

VISUAL:
Simple pie chart (centered):
- 60% slice: "Team" (Teal)
- 25% slice: "Infrastructure" (Gold)
- 15% slice: "GTM" (Charcoal)

BULLETS:
- Use of funds: 60% team expansion, 25% infrastructure, 15% GTM
- Milestones: 20 enterprise accounts, $3M ARR, Series A-ready metrics
- 18-month runway to profitability or next raise
- Exit vision: Strategic acquisition by luxury conglomerate or MarTech platform

STYLE:
- Clean, professional
- Clear ask
- Confident but not demanding
```

---

## PROMPT 17: SLIDE 16 - CLOSING

```
Create minimal, elegant closing slide.

TITLE: "Luxury Automation. Engineered."

CONTENT:
- Large wordmark: "SYNQRA" (Inter Black, centered)
- Company: "by NØID Labs" (below, smaller)
- Gold accent line (centered, 80% width)

CONTACT DETAILS (center-bottom):
- Name: "De Bear, Founder & CEO"
- Email: "debear@noidlux.com"
- Website: "synqra.co"
- Calendar: "[booking link]"

STYLE:
- Minimal, elegant
- Premium closing
- Memorable finish
- Easy to remember contact info
```

---

STATUS: ALL 16 SLIDES DEFINED ✅
READY FOR V0 EXECUTION ✅
