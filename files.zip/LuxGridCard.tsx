import React from "react";

interface LuxGridCardProps {
  children?: React.ReactNode;
  className?: string;
}

export default function LuxGridCard({ children, className = "" }: LuxGridCardProps) {
  return (
    <div className={`luxgrid-card ${className}`}>
      {children}
    </div>
  );
}
