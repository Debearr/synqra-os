import React from "react";

interface LuxGridSectionProps {
  title?: string;
  children?: React.ReactNode;
  className?: string;
}

export default function LuxGridSection({ title, children, className = "" }: LuxGridSectionProps) {
  return (
    <section className={`luxgrid-section ${className}`}>
      {title && <h2 className="luxgrid-section-title">{title}</h2>}
      {children}
    </section>
  );
}
