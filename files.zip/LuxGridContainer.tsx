import React from "react";

interface LuxGridContainerProps {
  children?: React.ReactNode;
  className?: string;
}

export default function LuxGridContainer({ children, className = "" }: LuxGridContainerProps) {
  return (
    <div className={`luxgrid-container ${className}`}>
      {children}
    </div>
  );
}
