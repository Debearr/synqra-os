# RAILWAY DEPLOYMENT FIX — APPLY NOW

## CRITICAL: Your app won't load because Railway is using Node 18 instead of Node 20

---

## FILE 1: nixpacks.toml (at repo root)
**Location:** Root of your repository (same level as package.json)
**Action:** Create this file if it doesn't exist, or replace its contents

```toml
[build]
nodejsVersion = "20"

[start]
cmd = "npm run start"

[variables]
NODE_ENV = "production"
```

---

## FILE 2: package.json (at repo root)
**Location:** Root package.json
**Action:** Add or update these sections

### Add to "engines":
```json
"engines": {
  "node": "20.x",
  "npm": ">=10.0.0"
}
```

### Verify "scripts" section has:
```json
"scripts": {
  "dev": "npm --prefix apps/synqra-mvp run dev",
  "build": "npm --prefix apps/synqra-mvp run build",
  "start": "npm --prefix apps/synqra-mvp run start"
}
```

---

## FILE 3: apps/synqra-mvp/package.json
**Location:** Inside your synqra-mvp app folder
**Action:** Update the "start" script

```json
"scripts": {
  "dev": "next dev",
  "build": "next build",
  "start": "next start -p ${PORT:-8080} --hostname 0.0.0.0",
  "lint": "next lint"
}
```

---

## FILE 4: Delete these if they exist
**Action:** Remove these files (they override nixpacks):
- `.nvmrc` (delete if exists)
- `.node-version` (delete if exists)
- `railway.json` (delete if exists, unless you specifically need it)

---

## DEPLOYMENT STEPS:

### Step 1: Apply Changes (5 minutes)
Open VS Code / Cursor:
1. Create/update `nixpacks.toml` at root
2. Update root `package.json` engines
3. Update `apps/synqra-mvp/package.json` start script
4. Delete `.nvmrc`, `.node-version`, `railway.json` (if they exist)

### Step 2: Commit and Push (2 minutes)
In your terminal:
```bash
git add .
git commit -m "fix: enforce Node 20 runtime for Railway"
git push origin main
```

### Step 3: Watch Railway Deploy (3 minutes)
- Railway automatically detects the push
- Watches build logs
- Look for "Node.js 20.x detected" in logs

### Step 4: Verify (1 minute)
Open browser:
```
https://synqra.co/api/health
```
Should return: `{"status": "ok"}`

Then visit:
```
https://synqra.co
```
App loads! ✅

---

## IF RAILWAY STILL USES NODE 18:

### Nuclear Option (Railway Dashboard):
1. Go to Railway project settings
2. Add environment variable:
   ```
   NIXPACKS_NODE_VERSION=20
   ```
3. Trigger manual redeploy
4. This forces Railway to use Node 20

---

## EXPECTED OUTCOME:

**Before:** synqra.co returns 502 Bad Gateway
**After:** synqra.co loads perfectly on all devices

**Timeline:** 10-15 minutes total

---

STATUS: READY TO APPLY ✅
YOUR PAIN ENDS IN 15 MINUTES ✅
