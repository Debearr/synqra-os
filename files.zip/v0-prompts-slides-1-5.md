# V0 PITCH DECK PROMPT SYSTEM
## Complete prompts for Synqra by NØID Labs investor deck

---

## PROMPT 1: DESIGN SYSTEM (EXECUTE THIS FIRST)

```
Create a Next.js design system for a luxury AI pitch deck with these specifications:

BRAND COLORS:
export const colors = {
  mattBlack: '#0A0A0A',
  gold: '#D4AF37',
  teal: '#008B8B',
  charcoal: '#2B2B2B',
  offWhite: '#F5F5F0',
  graphite: '#3C3C3C',
  burgundy: '#4A1C1C',
}

TYPOGRAPHY:
- Headings: Inter Bold or Helvetica Neue Bold, text-5xl (48px)
- Subheadings: Inter Regular, text-2xl (24px)
- Body: Inter Regular, text-lg (18px)
- Accent: Times New Roman or serif, text-sm (14px)

SPACING SYSTEM:
- Container: max-w-screen-xl mx-auto
- Section padding: py-20 px-24
- Element spacing: space-y-6
- Slide height: h-screen (full viewport)

DESIGN PRINCIPLES:
- Architectural minimalism (Rick Owens aesthetic)
- Premium negative space (more white space = more luxury)
- Asymmetric layouts (not everything centered)
- Subtle animations (0.4s cubic-bezier transitions)
- Dark luxury feel (matte black, no bright colors, no gradients)

BASE COMPONENTS NEEDED:
1. SlideContainer: Full viewport height, smooth scroll snap, off-white background
2. SlideTitle: text-5xl, font-bold, text-mattBlack, tracking-tight
3. SlideBullet: text-lg, text-graphite, leading-relaxed, gold bullet point
4. AccentLine: 4px thick gold line, w-4/5, centered
5. GeometricShape: Teal triangle/angular shape, opacity-30, absolute positioned

ANIMATION SPECS:
- Page transitions: 0.4s ease-in-out
- Element fades: 0.6s opacity transitions
- Hover effects: 0.2s color/transform changes
- No spinning, bouncing, or flashy animations

OUTPUT:
Generate Tailwind config, base layout component, and slide template components.
Use Shadcn UI for any buttons/interactive elements.
Make everything feel like Tom Ford meets Tesla meets Rick Owens.
```

---

## PROMPT 2: SLIDE 1 - COVER/HERO

```
Create a hero cover slide for "SYNQRA" investor pitch deck.

LAYOUT:
- Full viewport height (min-h-screen)
- Background: Off-white (#F5F5F0)
- Centered content with asymmetric elements

MAIN ELEMENTS:

1. SYNQRA WORDMARK (Center):
- Text: "SYNQRA"
- Font: text-8xl (96px), font-black, tracking-wider
- Color: Matte Black (#0A0A0A)
- Position: Centered vertically and horizontally

2. SUBTITLE (Below wordmark, 40px gap):
- Text: "Luxury Automation. Engineered."
- Font: text-2xl, font-normal
- Color: Charcoal (#2B2B2B)
- Position: Centered

3. TAGLINE (Below subtitle, 20px gap):
- Text: "The Intelligence Layer for Premium Brands"
- Font: text-lg, font-light
- Color: Graphite (#3C3C3C), opacity-60
- Position: Centered

4. GOLD ACCENT LINE:
- Position: Between wordmark and subtitle
- Width: 80% of screen width, max 400px
- Height: 4px
- Color: Gold (#D4AF37)
- Centered horizontally

5. TEAL GEOMETRIC ELEMENT:
- Shape: Angular triangle or abstract polygon (Rick Owens style)
- Size: 200×200px
- Color: Teal (#008B8B), opacity-30
- Position: Bottom-right corner, 40px margins

FOOTER (Bottom of slide, fixed):
- Left: "NØID Labs" (text-sm, opacity-60)
- Center: "De Bear, Founder & CEO" (text-sm, opacity-60)
- Right: "debear@noidlux.com" (text-sm, opacity-60)

ANIMATION:
- Wordmark fades in (0 to 1 opacity, 0.6s)
- Gold line draws from center outward (0.8s, 0.2s delay)
- Subtitle/tagline fade in (0.6s, 0.4s delay)
- Geometric element fades in (0.6s, 0.6s delay)

STYLE:
- Minimal, architectural
- Premium negative space (lots of breathing room)
- Dark luxury aesthetic
- No shadows, no gradients
- Clean, confident, expensive-looking
- Like a Tom Ford presentation opening
```

---

## PROMPT 3: SLIDE 2 - THE PROBLEM

```
Create "The Problem" slide with 3-column visual comparison.

TITLE: "The Luxury Content Dilemma"

LAYOUT:
- Off-white background
- Title at top (text-5xl, font-bold, text-mattBlack)
- Three equal-width columns below (with gaps)

COLUMN 1 (Generic AI):
- Container: p-8, border-2 border-graphite, opacity-40 (greyed out)
- Icon: Simple AI chip/brain symbol (muted colors)
- Label Above: "Generic AI" (text-xl, font-semibold)
- Features:
  * "Fast" (text-sm)
  * "Cheap" (text-sm)
- Problem Below: "Brand dilution" (text-sm, italic, text-red-600)

COLUMN 2 (The Gap) — CENTER, EMPHASIZED:
- Container: p-8, border-2 border-teal-500, bg-teal-500/5
- Icon: Question mark or empty space
- Label Above: "The Gap" (text-xl, font-semibold, text-teal)
- Features:
  * "Luxury Quality"
  * "+ AI Economics"
- Note: "← This is where SYNQRA fits" (text-gold, font-medium)

COLUMN 3 (Premium Agencies):
- Container: p-8, border-2 border-graphite, opacity-40 (greyed out)
- Icon: Luxury service/concierge symbol
- Label Above: "Premium Agencies" (text-xl, font-semibold)
- Features:
  * "$500+/item"
  * "Weeks to deliver"
- Problem Below: "Slow, expensive" (text-sm, italic, text-red-600)

BULLETS (Below columns, left-aligned):
• Luxury brands face impossible trade-off: speed vs. quality
• Generic AI creates brand dilution (sounds like everyone else)
• Premium agencies cost $500+/item, take weeks to deliver
• Gap: No solution for luxury-grade automation at scale

ANIMATION:
- Columns fade in sequentially (0.3s delay between each)
- "The Gap" column subtle pulse/glow effect (1.2s after load)
- Bullets appear one by one (0.15s delay each)

STYLE:
- Clean comparison layout
- Visual hierarchy (Gap column emphasized)
- Professional, not salesy
- Make the problem obvious at a glance
```

---

## PROMPT 4: SLIDE 3 - WHY NOW

```
Create "Why Now" slide with converging arrows visual.

TITLE: "The Perfect Timing"

VISUAL (Center of slide):
Four arrows pointing to center "NOW" circle:

ARROW 1 (From top-left, matte black):
- Text: "AI Fatigue"
- Sublabel: "Generic content flood"
- Arrow: Thick, pointing to center

ARROW 2 (From top-right, charcoal):
- Text: "E-commerce Growth"
- Sublabel: "Content needs at scale"
- Arrow: Thick, pointing to center

ARROW 3 (From bottom-left, graphite):
- Text: "Economic Pressure"
- Sublabel: "Efficiency without compromise"
- Arrow: Thick, pointing to center

ARROW 4 (From bottom-right, teal):
- Text: "Tech Maturity"
- Sublabel: "AI cost curves enable premium"
- Arrow: Thick, pointing to center

CENTER ELEMENT:
- Circle: 150px diameter, gold background
- Text: "NOW" (text-4xl, font-black, text-mattBlack)
- Subtle pulsing animation

BULLETS (Below visual):
- AI fatigue: Generic content flood drives demand for differentiation
- Luxury e-commerce growth: Content needs at unprecedented scale
- Economic pressure: Brands need efficiency without quality compromise
- Technology maturity: AI cost curves finally enable premium automation

STYLE:
- Clean, architectural diagram
- Four forces converging
- Visual metaphor for market timing
- Professional, confident
```

---

## PROMPT 5: SLIDE 4 - THE INSIGHT

```
Create "The Insight" slide with orchestra metaphor visual.

TITLE: "Orchestration Over Single Models"

VISUAL (Center):
Abstract orchestra representation using geometric shapes:

SHAPE 1 (Left, charcoal rectangle):
- Label: "Strategy AI"
- Size: 100×80px
- Position: Left side

SHAPE 2 (Center-left, graphite circle):
- Label: "Draft AI"
- Size: 90px diameter
- Position: Center-left

SHAPE 3 (Center, teal hexagon):
- Label: "Refine AI"
- Size: 85px
- Position: Center

SHAPE 4 (Center-right, gold triangle):
- Label: "Audit AI"
- Size: 95px
- Position: Center-right

SHAPE 5 (Right, burgundy square):
- Label: "SEO AI"
- Size: 80×80px
- Position: Right side

CONDUCTOR ELEMENT (Above shapes):
- Small gold baton icon
- Label: "Synqra Orchestration"
- Connecting lines to each shape (thin, gold)

BULLETS:
- Multiple specialized AIs outperform one general-purpose model
- Like an orchestra: each instrument plays its part
- Our proprietary routing: 97% cost savings without quality loss
- The moat isn't the model—it's the orchestration logic

ANIMATION:
- Shapes appear one by one (0.2s delays)
- Connecting lines draw after shapes appear
- Subtle floating/breathing animation on shapes

STYLE:
- Abstract, conceptual
- Virgil Abloh-style visual metaphor
- Clean, architectural
- Makes complex idea simple
```

---

## PROMPT 6: SLIDE 5 - THE SOLUTION

```
Create solution slide with split-screen cost comparison (emphasis slide).

BACKGROUND: Matte Black (#0A0A0A) — This is an EMPHASIS SLIDE

TITLE: "Luxury-Grade Content. AI Economics."
- Color: Gold (#D4AF37)

LAYOUT:
Split screen, 50/50:

LEFT SIDE:
- Large text: "$0.50+" (text-7xl, strikethrough, red line through it)
- Opacity: 40%
- Label below: "Industry Standard" (text-sm, opacity-60, off-white)

CENTER DIVIDING LINE:
- Vertical gold line (1px, full height)
- Small text on line: "97% savings" (rotated 90deg, gold)

RIGHT SIDE:
- Large text: "$0.016" (text-8xl, font-black, gold color)
- Label below: "Synqra" (text-xl, teal color)

BOTTOM SECTION:
Large text: "Same Luxury Quality"
- Font: Times New Roman (serif), italic
- Color: Off-white
- Size: text-3xl
- Position: Centered at bottom

BULLETS (Off-white text):
- Multi-tier AI routing for premium brand content
- $0.016/item vs. $0.50+ industry standard (97% savings)
- Use cases: Product descriptions, social content, campaign copy, SEO
- Enterprise + Creator tiers: Top-down and bottom-up growth

ANIMATION:
- Background fades from off-white to matte black (0.6s)
- Left price appears and crosses out (0.4s)
- Right price counts up from $0.00 to $0.016 (0.8s, dramatic)
- "97% savings" fades in (1.0s delay)
- Bottom text fades in (1.2s delay)

STYLE:
- High contrast (dark background, light text)
- Dramatic emphasis on price difference
- Simple, bold, memorable
- Like a luxury product reveal (iPhone launch style)
```

---

STATUS: SLIDES 1-5 COMPLETE ✅
DESIGN SYSTEM DEFINED ✅
READY FOR V0 ✅
