# 🔧 SYNQRA OS - RUNBOOK

## Auto-Heal Deployment System

### Overview
Synqra OS uses an intelligent auto-heal system that automatically fixes common deployment blockers before they cause failures.

---

## 🔍 Fix Deployment Blockers

### What It Does
The `fix:deployment-blockers` script is your automated preflight mechanic that:

1. **Validates Environment**
   - Checks `.env` file exists
   - Verifies all critical API keys are present
   - Ensures keys aren't using placeholder values

2. **Checks Dependencies**
   - Verifies `node_modules` exists
   - Ensures `package-lock.json` is present
   - Auto-installs dependencies if missing

3. **Validates Required Files**
   - Confirms `package.json` exists
   - Checks for deployment files
   - Verifies project structure

4. **Tests Service Connections**
   - Pings Supabase to verify database connection
   - Tests API key validity (where possible)
   - Reports connection status

5. **Fixes Common Issues**
   - Adds `.env` to `.gitignore` if missing
   - Makes scripts executable
   - Creates required directories (logs, public, etc.)
   - Generates missing files (manifest.json, favicon placeholder)

### How To Run

**Locally:**
```bash
npm run fix:deployment-blockers
```

**In CI/CD:**
```bash
node scripts/fix-deployment-blockers.js
```

### Expected Output

```
╔════════════════════════════════════════════════════════════╗
║   SYNQRA OS - DEPLOYMENT BLOCKER REPAIR                    ║
╚════════════════════════════════════════════════════════════╝

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
CHECKING ENVIRONMENT
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

✅ .env file exists
  ✅ ANTHROPIC_API_KEY
  ✅ SUPABASE_URL
  ✅ SUPABASE_SERVICE_KEY
✅ All critical environment variables configured

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
CHECKING DEPENDENCIES
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

✅ node_modules exists
✅ package-lock.json exists

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
TESTING SUPABASE CONNECTION
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Testing connection...
✅ Supabase connection successful

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
DEPLOYMENT READINESS REPORT
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

✅ ALL CHECKS PASSED - READY TO DEPLOY
```

---

## 🚀 CI/CD Auto-Heal Flow

### GitHub Actions Pipeline

Our deployment workflow includes intelligent auto-healing:

```
1. Checkout Code
   ↓
2. Setup Node.js & Install Dependencies
   ↓
3. Pre-flight Safety Checks
   - favicon.ico exists?
   - manifest.json exists?
   - Metadata present?
   ↓
4. Run fix:deployment-blockers (Attempt 1)
   ↓
5. Build Application (Attempt 1)
   ↓
   ├─ SUCCESS → Continue to deploy
   │
   └─ FAILURE → Auto-Heal Sequence:
      ├─ Clean build artifacts (.next, cache)
      ├─ Re-run fix:deployment-blockers
      ├─ Reinstall dependencies
      └─ Retry Build (Attempt 2)
         ↓
         ├─ SUCCESS → Deploy
         └─ FAILURE → Upload logs & fail gracefully
```

### What Happens On Failure

If the build fails after auto-heal:

1. **Logs Are Uploaded**
   - All error logs become downloadable artifacts
   - Retained for 7 days
   - Named: `build-failure-logs-{commit-sha}`

2. **Failure Summary Generated**
   - Commit SHA
   - Branch name
   - Auto-heal status
   - Common fixes listed

3. **No Silent Failures**
   - Clear error messages
   - Actionable next steps
   - Links to logs

### Triggering Deployments

**Automatic:**
- Push to `main` branch
- Push to `production` branch
- Pull request to `main` or `production`

**Manual:**
- Via GitHub Actions UI (workflow_dispatch)

---

## 📦 Deployment Targets

### Railway (App Backend)
- **Purpose:** Main application backend
- **URL:** `synqra-os.railway.internal`
- **Deploy:** `npm run deploy:railway`

### Vercel (Landing Page)
- **Purpose:** Public-facing landing page
- **Domain:** `synqra.com`
- **Deploy:** `npm run deploy:vercel`

### Local Development
- **NOID Dashboard:** http://localhost:3000
- **Health Checks:** http://localhost:3003
- **Start:** `npm run dev`

---

## 🔐 Environment Variables

### Required (Core Functionality)

```bash
# Claude API
ANTHROPIC_API_KEY=sk-ant-api03-...
CLAUDE_API_KEY=sk-ant-api03-...

# Supabase Database
SUPABASE_URL=https://your-project.supabase.co
SUPABASE_ANON_KEY=eyJhbGci...
SUPABASE_SERVICE_KEY=eyJhbGci...

# App Configuration
NEXT_PUBLIC_APP_URL=https://app.synqra.com
NODE_ENV=production
PORT=3000
```

### Optional (Extended Features)

```bash
# Additional AI Models
OPENAI_API_KEY=sk-proj-...
KIE_API_KEY=...
GEMINI_API_KEY=...
LEONARDO_API_KEY=...

# Messaging
TELEGRAM_BOT_TOKEN=123456789:ABC...
TELEGRAM_CHANNEL_ID=@your_channel

# Payments
STRIPE_SECRET_KEY=sk_test_...
STRIPE_WEBHOOK_SECRET=whsec_...

# Deployment
RAILWAY_TOKEN=...
GITHUB_TOKEN=ghp_...
```

---

## 🧪 Testing Checklist

### Before Deployment

- [ ] Run `npm run fix:deployment-blockers`
- [ ] All checks pass
- [ ] `.env` file has all required keys
- [ ] No placeholder values in `.env`
- [ ] `npm run build` succeeds locally
- [ ] Health endpoint returns 200

### After Deployment

- [ ] App loads without errors
- [ ] Favicon visible in browser tab
- [ ] Metadata correct (title, description)
- [ ] Database connection working
- [ ] API keys valid
- [ ] Logs show no errors

### Visual Test (2 minutes)

1. **Landing Page**
   - [ ] Loads correctly
   - [ ] Images load
   - [ ] Links work
   - [ ] Responsive on mobile

2. **Dashboard**
   - [ ] Login works
   - [ ] Data fetches correctly
   - [ ] Actions complete
   - [ ] No console errors

3. **Health Check**
   - [ ] All services "connected"
   - [ ] No warnings
   - [ ] Timestamp current

---

## 🐛 Common Issues & Fixes

### Issue: "Missing environment variable"

**Fix:**
```bash
# Copy template
cp .env.template .env

# Fill in your keys
nano .env

# Validate
npm run validate
```

### Issue: "Build failed"

**Fix:**
```bash
# Clean everything
rm -rf .next node_modules package-lock.json

# Fresh install
npm install

# Run fix
npm run fix:deployment-blockers

# Retry build
npm run build
```

### Issue: "Port already in use"

**Fix:**
```bash
# Find process
lsof -ti:3000

# Kill it
kill -9 $(lsof -ti:3000)

# Restart
npm run dev
```

### Issue: "Supabase connection failed"

**Fix:**
1. Check `.env` has correct `SUPABASE_URL`
2. Verify `SUPABASE_SERVICE_KEY` is correct
3. Ensure Supabase project is active
4. Check network/firewall settings

---

## 📞 Quick Commands

```bash
# Validate everything
npm run validate

# Start development
npm run dev

# Build for production
npm run build

# Start production server
npm start

# Check health
npm run health

# View logs
npm run logs

# Deploy to Railway
npm run deploy:railway

# Deploy to Vercel
npm run deploy:vercel
```

---

## 🎯 Next Steps

1. **Run locally first**
   ```bash
   npm run fix:deployment-blockers
   npm run dev
   ```

2. **Test thoroughly**
   - Visit http://localhost:3000
   - Check all features work
   - Monitor console for errors

3. **Deploy to staging**
   ```bash
   git push origin staging
   ```

4. **Monitor deployment**
   - Watch GitHub Actions
   - Check auto-heal status
   - Review logs if needed

5. **Deploy to production**
   ```bash
   git push origin main
   ```

---

## 📚 Additional Resources

- **Setup Guide:** `/FINAL_SETUP_GUIDE.md`
- **Environment Template:** `/.env.template`
- **Fix Script:** `/scripts/fix-deployment-blockers.js`
- **CI/CD Workflow:** `/.github/workflows/deployment.yml`

---

**Last Updated:** November 2, 2025  
**Version:** 1.0.0  
**Maintainer:** Synqra Team
