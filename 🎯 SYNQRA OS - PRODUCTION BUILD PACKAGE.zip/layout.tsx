// app/layout.tsx (or create this file if it doesn't exist)
import type { Metadata } from 'next'

export const metadata: Metadata = {
  title: {
    default: 'Synqra OS - AI-Powered Automation Platform',
    template: '%s | Synqra OS'
  },
  description: 'Multi-model AI intelligence platform featuring self-healing systems, automated trading signals (AuraFX), and enterprise automation. Powered by Claude, GPT, Gemini, and custom AI models.',
  keywords: [
    'AI automation',
    'trading signals',
    'AuraFX',
    'multi-model AI',
    'Claude AI',
    'GPT',
    'self-healing systems',
    'SCIN',
    'LuxGrid',
    'NOID dashboard'
  ],
  authors: [{ name: 'Synqra Team' }],
  creator: 'Synqra',
  publisher: 'Synqra',
  formatDetection: {
    email: false,
    address: false,
    telephone: false,
  },
  metadataBase: new URL(process.env.NEXT_PUBLIC_APP_URL || 'https://synqra.com'),
  openGraph: {
    title: 'Synqra OS - AI-Powered Automation Platform',
    description: 'Multi-model AI intelligence platform with self-healing systems and automated trading signals.',
    url: process.env.NEXT_PUBLIC_APP_URL || 'https://synqra.com',
    siteName: 'Synqra OS',
    images: [
      {
        url: '/og-image.png',
        width: 1200,
        height: 630,
        alt: 'Synqra OS - AI Automation Platform',
      },
    ],
    locale: 'en_US',
    type: 'website',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'Synqra OS - AI-Powered Automation Platform',
    description: 'Multi-model AI intelligence with self-healing systems and trading signals.',
    images: ['/og-image.png'],
    creator: '@synqra',
  },
  robots: {
    index: true,
    follow: true,
    googleBot: {
      index: true,
      follow: true,
      'max-video-preview': -1,
      'max-image-preview': 'large',
      'max-snippet': -1,
    },
  },
  icons: {
    icon: '/favicon.ico',
    shortcut: '/favicon.ico',
    apple: '/apple-touch-icon.png',
  },
  manifest: '/manifest.json',
  viewport: {
    width: 'device-width',
    initialScale: 1,
    maximumScale: 5,
  },
  themeColor: [
    { media: '(prefers-color-scheme: light)', color: '#ffffff' },
    { media: '(prefers-color-scheme: dark)', color: '#000000' },
  ],
  verification: {
    google: 'YOUR_GOOGLE_VERIFICATION_CODE', // Add when ready
    // yandex: 'YOUR_YANDEX_CODE',
    // yahoo: 'YOUR_YAHOO_CODE',
  },
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en">
      <head>
        <link rel="icon" href="/favicon.ico" sizes="any" />
        <link rel="apple-touch-icon" href="/apple-touch-icon.png" />
        <link rel="manifest" href="/manifest.json" />
      </head>
      <body>{children}</body>
    </html>
  )
}
