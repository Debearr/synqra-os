# Cursor Agents Configuration
# NØID Labs Autonomous Agent Definitions
# Version: 1.0 | Updated: 2025-11-12

## WHAT IS THIS FILE?

This file defines **autonomous agents** that Cursor can run in the background. Each agent has a specific purpose and can work independently while you focus on other tasks.

**When to use Agents vs .cursorrules:**
- **agents.md** → For long-running, background tasks (multi-hour builds)
- **.cursorrules** → For immediate, interactive commands (quick fixes)

---

## AGENT 1: Health Monitor
**Purpose:** Continuous monitoring of all NØID Labs products
**Trigger:** "monitor health" | "watch system" | "continuous check"
**Runtime:** Indefinite (runs until stopped)

### Configuration
```yaml
agent_name: health_monitor
priority: high
auto_restart: true
check_interval: 5 minutes
alert_threshold: 2 consecutive failures
```

### Actions
1. **Every 5 minutes, check:**
   - Supabase database connection
   - Railway deployment status
   - Production URL response time
   - API endpoint health (/api/health)
   - Environment variables loaded

2. **Log results to:**
   - `.health-monitor/logs/[timestamp].json`
   - Console (if terminal open)
   - Create alert file if failures detected

3. **Auto-heal if possible:**
   - Restart failed services
   - Clear cache if 500 errors
   - Reconnect to database
   - Only fix known issues (don't guess)

4. **Alert conditions:**
   - 2+ consecutive failed checks → Create `.health-monitor/ALERT.txt`
   - Database timeout > 5s → Log warning
   - API response time > 2s → Log performance issue

### Output Format
```json
{
  "timestamp": "2025-11-12T15:30:00Z",
  "status": "healthy",
  "checks": {
    "database": { "status": "ok", "latency": "45ms" },
    "railway": { "status": "ok", "uptime": "99.9%" },
    "api_health": { "status": "ok", "response_time": "120ms" },
    "env_vars": { "status": "ok", "loaded": 12 }
  },
  "actions_taken": []
}
```

### Stop Command
Type: "stop monitoring" | "pause agent"

---

## AGENT 2: Auto-Healer
**Purpose:** Detect and fix common errors automatically
**Trigger:** "auto-heal" | "continuous fix" | "watch and repair"
**Runtime:** Indefinite (runs until stopped)

### Configuration
```yaml
agent_name: auto_healer
priority: high
scan_interval: 2 minutes
max_fixes_per_run: 3
require_approval: false  # Auto-executes known fixes
```

### Monitored Errors
1. **MODULE_NOT_FOUND**
   - Fix: Install missing package
   - Commit: "fix: add missing dependency [package]"

2. **404 on Routes**
   - Fix: Create missing page.tsx
   - Commit: "fix: add missing route [path]"

3. **TypeScript Errors**
   - Fix: Add missing types
   - Commit: "fix: resolve TypeScript errors in [file]"

4. **Build Failures**
   - Fix: Clear .next cache, rebuild
   - Commit: "fix: clear cache and rebuild"

5. **Environment Variable Missing**
   - Fix: Add to .env.local.template
   - Alert: "Manual action required: Add [VAR] to Railway"

### Safety Limits
- Max 3 auto-fixes per 10-minute window
- Never delete files without backup
- Always test fix before committing
- Stop if same error repeats 3 times
- Create issue template if can't fix

### Actions Log
```
[15:32] Detected: MODULE_NOT_FOUND 'pg'
[15:32] Action: Running npm install pg
[15:33] Result: ✅ Package installed
[15:33] Action: Testing script
[15:33] Result: ✅ Script runs successfully
[15:33] Action: Committing fix
[15:34] Result: ✅ Committed as "fix: add missing pg dependency"
```

---

## AGENT 3: Feature Builder
**Purpose:** Build complete features autonomously from description
**Trigger:** "build [feature-name]" | "create [component-name]" | "implement [functionality]"
**Runtime:** Until feature complete (30 min - 4 hours)

### Configuration
```yaml
agent_name: feature_builder
priority: medium
planning_phase: required  # Always plan before building
approval_required: true   # Wait for "✅ proceed" before execution
branch_strategy: feature/[feature-name]
```

### Planning Phase (Always First)
1. **Understand requirements:**
   - Read user description
   - Ask clarifying questions if ambiguous
   - Check for related SKILL.md files

2. **Create implementation plan:**
   ```
   FEATURE: User Profile Page
   
   Files to create:
   - app/(synqra)/profile/page.tsx
   - app/(synqra)/profile/components/ProfileCard.tsx
   - app/(synqra)/profile/components/EditModal.tsx
   - lib/profile/types.ts
   - lib/profile/utils.ts
   - api/profile/route.ts
   
   Dependencies needed:
   - None (using existing packages)
   
   Estimated time: 45 minutes
   ```

3. **Wait for approval:**
   - Show plan to user
   - User must type: "✅ proceed" | "continue" | "build it"
   - If user says "change [X]", revise plan

### Execution Phase
1. **Create branch:**
   - `git checkout -b feature/[feature-name]`

2. **Build in sequence:**
   - Create folder structure
   - Generate TypeScript types first
   - Build utility functions
   - Create components (bottom-up)
   - Add API routes if needed
   - Write basic tests

3. **Test continuously:**
   - After each component: `npm run dev` + manual check
   - After all files: `npm run build`
   - Run TypeScript check: `npm run type-check`

4. **Commit incrementally:**
   - "feat: add [component-name]"
   - "feat: implement [functionality]"
   - Final: "feat: complete [feature-name]"

5. **Create PR:**
   - Push branch to GitHub
   - Generate PR description
   - Link any related issues
   - Assign to user for review

### Quality Checklist (Before PR)
- [ ] All TypeScript types defined
- [ ] No 'any' types used
- [ ] Components follow brand DNA
- [ ] Responsive on mobile/desktop
- [ ] No console.log statements
- [ ] Error handling implemented
- [ ] Loading states included
- [ ] Accessibility labels added

---

## AGENT 4: Deployment Manager
**Purpose:** Handle full deployment lifecycle with monitoring
**Trigger:** "deploy to [environment]" | "ship to production" | "release [version]"
**Runtime:** Until deployment verified (~10 minutes)

### Configuration
```yaml
agent_name: deployment_manager
priority: critical
environments: [staging, production]
rollback_enabled: true
health_check_timeout: 5 minutes
```

### Pre-Deployment Checklist
**Automatically verify before deploying:**
1. All tests passing (`npm run test`)
2. Build succeeds (`npm run build`)
3. TypeScript clean (`npm run type-check`)
4. Linter clean (`npm run lint`)
5. No secrets in code (grep for API keys)
6. .env files in .gitignore
7. Migrations ready (if database changes)

**If ANY check fails:**
- Stop deployment
- Show which check failed
- Offer to fix automatically
- Re-run checks after fix

### Deployment Sequence

**Stage 1: Pre-Deploy**
```
[15:45] Starting deployment to production
[15:45] Running pre-deployment checks...
[15:46] ✅ Tests passed (23/23)
[15:46] ✅ Build succeeded
[15:46] ✅ TypeScript clean
[15:46] ✅ Linter clean
[15:46] ✅ No secrets detected
[15:46] ✅ All checks passed
```

**Stage 2: Deploy**
```
[15:47] Creating backup of current deployment
[15:47] ✅ Backup saved: deploy-2025-11-12-1547
[15:47] Pushing to GitHub (main branch)
[15:48] ✅ Pushed successfully
[15:48] Waiting for Railway to detect changes...
[15:49] Railway deployment started: dpl_abc123
```

**Stage 3: Monitor**
```
[15:50] Deployment in progress (1/5 minutes)
[15:51] Deployment in progress (2/5 minutes)
[15:52] Deployment completed on Railway
[15:52] Testing production URL...
[15:53] ✅ https://synqra.co returns 200 OK
[15:53] ✅ /api/health returns healthy
```

**Stage 4: Verify**
```
[15:54] Running post-deployment checks...
[15:54] ✅ Homepage loads correctly
[15:54] ✅ Database connection active
[15:55] ✅ All API routes responding
[15:55] 🎉 Deployment successful!
```

### Rollback Protocol (if deployment fails)

**Automatic rollback if:**
- Production URL returns 500 error
- Database connection fails
- Critical API route broken
- Health check fails for 2 minutes

**Rollback steps:**
1. Alert: "⚠️ Deployment failed, initiating rollback"
2. Revert to backup: `deploy-[timestamp]`
3. Redeploy previous version
4. Verify previous version works
5. Create incident report with error logs

### Post-Deployment Report
```
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
🚀 DEPLOYMENT REPORT
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Environment: Production
Started: 2025-11-12 15:45:00 UTC
Completed: 2025-11-12 15:55:00 UTC
Duration: 10 minutes

Status: ✅ SUCCESS

Changes deployed:
- feat: user profile page
- fix: navigation menu bug
- perf: optimize image loading

URLs verified:
✅ https://synqra.co
✅ https://synqra.co/api/health
✅ https://synqra.co/profile

Rollback available:
deploy-2025-11-12-1547

Next steps:
- Monitor for errors (first 24h critical)
- Check user feedback
- Update changelog
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
```

---

## AGENT 5: Documentation Generator
**Purpose:** Auto-generate and maintain project documentation
**Trigger:** "update docs" | "generate documentation" | "document [feature]"
**Runtime:** Until docs complete (~15 minutes)

### Configuration
```yaml
agent_name: doc_generator
priority: low
output_format: markdown
include_examples: true
update_changelog: true
```

### Documentation Types

**1. Component Documentation**
For each component in /components:
```markdown
# ComponentName

## Purpose
Brief description of what this component does.

## Props
| Prop | Type | Required | Default | Description |
|------|------|----------|---------|-------------|
| title | string | Yes | - | The heading text |
| onClick | function | No | undefined | Click handler |

## Usage
\`\`\`tsx
import { ComponentName } from '@/components/ComponentName';

<ComponentName 
  title="Hello World"
  onClick={() => console.log('clicked')}
/>
\`\`\`

## Styling
- Uses Tailwind utility classes
- Follows NØID Labs brand DNA
- Responsive breakpoints: sm, md, lg, xl

## Dependencies
- None (pure component)
```

**2. API Documentation**
For each route in /api:
```markdown
# API Endpoint: /api/profile

## GET /api/profile
Retrieves user profile data.

### Authentication
Requires: Bearer token in Authorization header

### Response
\`\`\`json
{
  "id": "user_123",
  "name": "John Doe",
  "email": "john@example.com"
}
\`\`\`

### Error Codes
- 401: Unauthorized (missing/invalid token)
- 404: User not found
- 500: Server error

### Example
\`\`\`bash
curl -H "Authorization: Bearer token" \\
  https://synqra.co/api/profile
\`\`\`
```

**3. Changelog**
Auto-update CHANGELOG.md:
```markdown
# Changelog

## [1.2.0] - 2025-11-12

### Added
- User profile page with edit functionality
- Profile picture upload
- Bio section with markdown support

### Fixed
- Navigation menu mobile responsiveness
- Database connection timeout handling

### Changed
- Updated profile API to include bio field
- Improved error messages

### Performance
- Optimized image loading (+40% faster)
- Reduced bundle size (-15%)
```

**4. README Updates**
Keep README.md current:
- Update feature list
- Add new setup instructions
- Include latest dependencies
- Update deployment steps
- Refresh screenshots if UI changed

### Execution
1. Scan codebase for changes since last doc update
2. Generate docs for new/modified files
3. Update existing docs if function signatures changed
4. Compile changelog from git commits
5. Update README with new features
6. Commit: "docs: update documentation for [feature]"

---

## AGENT 6: Performance Optimizer
**Purpose:** Monitor and optimize app performance automatically
**Trigger:** "optimize performance" | "speed check" | "find bottlenecks"
**Runtime:** One-time analysis (~30 minutes)

### Configuration
```yaml
agent_name: performance_optimizer
priority: low
metrics_tracked: [bundle_size, load_time, lcp, fid, cls]
lighthouse_score_target: 90
```

### Analysis Steps

**1. Bundle Size Analysis**
```
Analyzing bundle size...
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Current size: 487 KB
Target: < 300 KB
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Largest dependencies:
1. moment.js - 67 KB (recommend: date-fns)
2. lodash - 54 KB (recommend: lodash-es)
3. chart.js - 43 KB (consider: lazy load)

Recommended actions:
✅ Replace moment.js with date-fns (-45 KB)
✅ Use lodash-es for tree-shaking (-30 KB)
✅ Lazy load chart.js on demand (-43 KB)

Potential savings: -118 KB (24% reduction)
```

**2. Load Time Optimization**
```
Analyzing load times...
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Homepage LCP: 2.4s (target: < 2.5s)
Dashboard LCP: 3.8s (⚠️ needs improvement)
Profile LCP: 1.9s (✅ good)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Slow components:
1. Dashboard DataTable - 1.2s render
2. ProfileChart - 890ms render
3. NotificationList - 670ms render

Recommendations:
✅ Add React.memo to DataTable
✅ Lazy load ProfileChart
✅ Virtualize NotificationList (react-window)
✅ Add loading skeletons for perceived speed
```

**3. Image Optimization**
```
Scanning images...
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Found: 47 images
Total size: 8.3 MB
Unoptimized: 23 images
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Issues found:
⚠️ 12 PNG files should be WebP (-60% size)
⚠️ 8 images missing width/height (CLS risk)
⚠️ 3 images not using Next.js Image component

Auto-fix available:
✅ Convert PNG → WebP
✅ Add dimensions to <img> tags
✅ Replace <img> with <Image>

Run fixes? (y/n)
```

**4. Code Splitting Analysis**
```
Checking code splitting...
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Route-level splitting: ✅ Good
Component-level splitting: ⚠️ Could improve
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Large components to split:
1. Dashboard.tsx (345 KB)
   → Split into: Overview, Analytics, Settings
2. ProfileEditor.tsx (234 KB)
   → Lazy load: ImageCropper, FormWizard

Implement dynamic imports? (y/n)
```

### Output Report
Creates: `.performance/report-[timestamp].md` with full analysis and action items.

---

## AGENT 7: Security Auditor
**Purpose:** Scan for security vulnerabilities and fix automatically
**Trigger:** "security audit" | "check vulnerabilities" | "scan for issues"
**Runtime:** One-time scan (~20 minutes)

### Configuration
```yaml
agent_name: security_auditor
priority: critical
auto_fix: safe_only  # Only auto-fix known-safe issues
report_level: verbose
```

### Security Checks

**1. Dependency Vulnerabilities**
```bash
Running: npm audit
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Found: 3 vulnerabilities (1 high, 2 moderate)

High severity:
- axios@0.27.2 (SSRF vulnerability)
  Fix: npm install axios@latest
  Auto-fix: ✅ Safe to update

Moderate severity:
- semver@7.3.5 (ReDoS vulnerability)
  Fix: npm install semver@latest
  Auto-fix: ✅ Safe to update

- minimist@1.2.5 (Prototype pollution)
  Fix: npm install minimist@latest
  Auto-fix: ⚠️ Breaking changes possible
  
Apply safe auto-fixes? (y/n)
```

**2. Secret Scanning**
```bash
Scanning for exposed secrets...
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

❌ CRITICAL: API key found!
File: src/utils/api.ts
Line: 12
Content: const API_KEY = "sk-proj-abc123..."

Action required:
1. Remove hardcoded key immediately
2. Add to .env.local
3. Update code to use: process.env.API_KEY
4. Rotate API key (it's now compromised)

Auto-fix: ⚠️ Requires manual key rotation
```

**3. SQL Injection Check**
```javascript
Checking database queries...
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

⚠️ Potential SQL injection found!
File: api/users/route.ts
Line: 45

Vulnerable code:
const query = `SELECT * FROM users WHERE id = ${req.query.id}`;

Recommended fix:
const query = supabase
  .from('users')
  .select('*')
  .eq('id', req.query.id);  // Parameterized query

Apply fix? (y/n)
```

**4. XSS Vulnerability Check**
```javascript
Scanning for XSS risks...
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

⚠️ Potential XSS found!
File: components/CommentDisplay.tsx
Line: 23

Vulnerable code:
<div dangerouslySetInnerHTML={{ __html: comment }} />

Recommended fix:
import DOMPurify from 'dompurify';
<div dangerouslySetInnerHTML={{ 
  __html: DOMPurify.sanitize(comment) 
}} />

Apply fix? (y/n)
```

### Security Report
Creates: `.security/audit-[timestamp].md` with:
- List of all vulnerabilities found
- Severity ratings
- Recommended fixes
- Auto-fixed issues
- Manual action items

---

## AGENT MANAGEMENT COMMANDS

### Start Agent
```
"start [agent-name]"
Example: "start health_monitor"
```

### Stop Agent
```
"stop [agent-name]"
"pause [agent-name]"
Example: "stop health_monitor"
```

### List Active Agents
```
"show agents"
"list running agents"
```

Output:
```
🤖 ACTIVE AGENTS
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
✅ health_monitor (running 2h 34m)
✅ auto_healer (running 45m)
❌ feature_builder (stopped)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
```

### Check Agent Status
```
"status [agent-name]"
Example: "status health_monitor"
```

### Agent Logs
```
"show logs [agent-name]"
"tail [agent-name]"
```

---

## INTEGRATION WITH .CURSORRULES

**How these work together:**

**.cursorrules** handles:
- Immediate, interactive commands
- Quick fixes and diagnostics
- Real-time user requests
- Synchronous operations

**agents.md** handles:
- Long-running background tasks
- Continuous monitoring
- Multi-step feature builds
- Asynchronous operations

**Example workflow:**
1. User types: "build user profile" (uses .cursorrules)
2. Cursor shows plan, waits for approval
3. User types: "✅ proceed" 
4. Cursor starts feature_builder AGENT (uses agents.md)
5. Agent works in background for 45 minutes
6. User continues other work
7. Agent notifies when complete

---

## BEST PRACTICES

### When to Use Agents:
✅ Building complete features (>30 min work)
✅ Continuous monitoring
✅ Long-running optimizations
✅ Background security scans
✅ Automated testing suites

### When to Use .cursorrules:
✅ Quick fixes (<5 min)
✅ Immediate diagnostics
✅ Interactive debugging
✅ File navigation
✅ Rapid prototyping

### Agent Safety:
- Agents auto-commit their work
- Always create feature branches
- Never push directly to main
- Stop agent if >3 consecutive failures
- Log all actions to `.agents/logs/`

---

## FUTURE AGENT IDEAS

**Coming soon:**
- `cost_optimizer` → Monitor Railway/Vercel costs, suggest savings
- `test_generator` → Auto-create tests for new components
- `seo_optimizer` → Audit and improve SEO scores
- `accessibility_checker` → Ensure WCAG compliance
- `translation_manager` → Auto-translate UI strings

**Want to add a custom agent?**
1. Define configuration in this file
2. Set trigger phrase
3. List actions to take
4. Specify safety limits
5. Test in isolated branch first

---

🤖 **END OF AGENTS.MD** | Ready for autonomous work
