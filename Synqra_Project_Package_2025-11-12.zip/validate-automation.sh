#!/bin/bash

# NØID Labs Automation Validation Script
# Run this after installing .cursorrules and agents.md

echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "🔍 NØID Labs Automation System Validator"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo ""

# Check if running in project root
if [ ! -f "package.json" ]; then
    echo "❌ ERROR: Not in project root"
    echo "💡 TIP: cd to your project directory first"
    exit 1
fi

echo "📍 Project: $(pwd)"
echo ""

# Check for automation files
echo "🔍 Checking automation files..."
if [ -f ".cursorrules" ]; then
    echo "✅ .cursorrules found ($(du -h .cursorrules | cut -f1))"
else
    echo "❌ .cursorrules missing"
    echo "💡 Copy from: /mnt/user-data/outputs/.cursorrules"
fi

if [ -f "agents.md" ]; then
    echo "✅ agents.md found ($(du -h agents.md | cut -f1))"
else
    echo "⚠️  agents.md missing (optional but recommended)"
fi

echo ""
echo "🔍 Checking project structure..."

# Check critical folders
folders=("app" "components" "lib" "public")
for folder in "${folders[@]}"; do
    if [ -d "$folder" ]; then
        echo "✅ $folder/ exists"
    else
        echo "⚠️  $folder/ missing (may be expected for some projects)"
    fi
done

echo ""
echo "🔍 Checking dependencies..."

# Check if node_modules exists
if [ -d "node_modules" ]; then
    echo "✅ node_modules installed"
else
    echo "⚠️  node_modules missing"
    echo "💡 RUN: npm install"
fi

# Check package.json scripts
if grep -q '"dev"' package.json; then
    echo "✅ npm run dev available"
fi

if grep -q '"build"' package.json; then
    echo "✅ npm run build available"
fi

echo ""
echo "🔍 Checking environment..."

# Check for .env file
if [ -f ".env.local" ]; then
    echo "✅ .env.local found"
elif [ -f ".env" ]; then
    echo "✅ .env found"
else
    echo "⚠️  No .env file found"
    echo "💡 TIP: Create .env.local with your secrets"
fi

echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "📊 VALIDATION SUMMARY"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

# Count checks
total_checks=10
passed_checks=0

[ -f ".cursorrules" ] && ((passed_checks++))
[ -f "agents.md" ] && ((passed_checks++))
[ -d "app" ] && ((passed_checks++))
[ -d "components" ] && ((passed_checks++))
[ -d "lib" ] && ((passed_checks++))
[ -d "node_modules" ] && ((passed_checks++))
[ -f ".env.local" ] || [ -f ".env" ] && ((passed_checks++))
grep -q '"dev"' package.json && ((passed_checks++))
grep -q '"build"' package.json && ((passed_checks++))
[ -f "package.json" ] && ((passed_checks++))

echo "Passed: $passed_checks/$total_checks checks"
echo ""

if [ $passed_checks -ge 8 ]; then
    echo "✅ READY TO USE"
    echo ""
    echo "🚀 Next Steps:"
    echo "1. Open Cursor in this directory"
    echo "2. Press Cmd/Ctrl + I"
    echo "3. Type: health check"
    echo "4. Watch automation activate! ✨"
elif [ $passed_checks -ge 5 ]; then
    echo "⚠️  ALMOST READY"
    echo ""
    echo "🔧 Fix these issues first:"
    [ ! -f ".cursorrules" ] && echo "  - Copy .cursorrules to project root"
    [ ! -d "node_modules" ] && echo "  - Run: npm install"
    [ ! -f ".env.local" ] && [ ! -f ".env" ] && echo "  - Create .env.local with your secrets"
else
    echo "❌ NOT READY"
    echo ""
    echo "🔧 Required actions:"
    [ ! -f "package.json" ] && echo "  - Not a Node.js project?"
    [ ! -f ".cursorrules" ] && echo "  - Copy .cursorrules to project root"
    [ ! -d "node_modules" ] && echo "  - Run: npm install"
fi

echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
