# NØID Labs Automation System

## 🚀 Quick Start

1. Copy these files to your project root:
   - `.cursorrules`
   - `agents.md`
   - `CURSOR_CHEAT_SHEET.md`

2. Open Cursor and type:
   ```
   health check
   ```

3. Watch automation activate!

## 📦 What's Included

- **50+ automation triggers** (health check, fix now, deploy, etc.)
- **7 autonomous agents** (health monitor, auto-healer, feature builder)
- **Brand DNA enforcement** (automatic luxury styling)
- **Security protocols** (never expose secrets)
- **Self-healing capabilities** (auto-fix common errors)

## 🎯 Core Commands

```bash
"health check"   # System diagnostic
"fix now"        # Auto-heal issues
"build [feature]" # Create feature
"deploy"         # Push to production
"rollback"       # Revert deployment
```

## 💡 Pro Tips

- Start every session with `"health check"`
- Let agents work in background
- Use trigger phrases (not explanations)
- Trust the auto-heal system

---

Built for NØID Labs | Synqra, NØID, AuraFX
