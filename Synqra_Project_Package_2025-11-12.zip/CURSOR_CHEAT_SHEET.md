# CURSOR COMMAND CENTER
## Quick Reference | NØID Labs Edition

**Last Updated:** 2025-11-12  
**Version:** 1.0  
**For:** Synqra, NØID, AuraFX

---

## 🎹 KEYBOARD SHORTCUTS

### Essential Shortcuts
| Shortcut | Action | Use When |
|----------|--------|----------|
| `Cmd/Ctrl + I` | Open Composer | Building features |
| `Cmd/Ctrl + L` | Open Chat | Quick questions |
| `Cmd/Ctrl + Shift + I` | Start Agent | Background work |
| `Cmd/Ctrl + S` | Save File | After editing |
| `Cmd/Ctrl + /` | Toggle Comment | Commenting code |
| `Cmd/Ctrl + D` | Duplicate Line | Repeating code |
| `Cmd/Ctrl + X` | Cut Line | Moving code |
| `Cmd/Ctrl + Z` | Undo | Fixing mistakes |
| `Cmd/Ctrl + Shift + Z` | Redo | Undoing undo |
| `Cmd/Ctrl + F` | Find in File | Searching code |
| `Cmd/Ctrl + Shift + F` | Find in Project | Global search |
| `Cmd/Ctrl + P` | Quick Open File | Navigation |
| `Cmd/Ctrl + B` | Toggle Sidebar | More screen space |
| `Cmd/Ctrl + J` | Toggle Terminal | Running commands |
| `Cmd/Ctrl + K` | Clear Terminal | Clean output |

### Advanced Shortcuts
| Shortcut | Action | Use When |
|----------|--------|----------|
| `Alt + Up/Down` | Move Line Up/Down | Reordering code |
| `Cmd/Ctrl + Shift + K` | Delete Line | Removing code |
| `Cmd/Ctrl + Enter` | Insert Line Below | Adding new line |
| `Cmd/Ctrl + Shift + Enter` | Insert Line Above | Adding above |
| `Cmd/Ctrl + ]` | Indent | Formatting |
| `Cmd/Ctrl + [` | Outdent | Formatting |
| `Cmd/Ctrl + /` | Toggle Comment | Commenting |
| `Alt + Click` | Multi-cursor | Editing multiple spots |
| `Cmd/Ctrl + Alt + Up/Down` | Add Cursor Above/Below | Column editing |

---

## 🎯 QUICK TRIGGERS

### Diagnostics & Status
```
"health check"        → Full system diagnostic
"diagnose"            → Same as health check
"status check"        → Current state report
"where am i"          → Show current directory
"show structure"      → Display folder tree
"show logs"           → Recent error logs
```

### Auto-Fix & Repair
```
"fix now"             → Auto-heal detected issues
"auto-heal"           → Same as fix now
"repair"              → Fix and commit
"clean install"       → Reinstall node_modules
```

### Build & Create
```
"build [feature]"     → Create new feature
"create [component]"  → Generate component
"add [functionality]" → Implement capability
"scaffold [page]"     → Create page structure
```

### Deployment
```
"deploy"              → Push to production
"ship it"             → Same as deploy
"go live"             → Deploy with validation
"rollback"            → Revert to previous
```

### Testing
```
"test locally"        → Run npm run dev
"build test"          → Run npm run build
"type check"          → TypeScript validation
"lint check"          → Run ESLint
```

### Navigation
```
"open [file]"         → Open specific file
"list files"          → Show files here
"go to [path]"        → Navigate to folder
```

### Help & Info
```
"help"                → Show all triggers
"show rules"          → Display .cursorrules
"examples"            → Example workflows
"cheat sheet"         → This document
```

---

## 🔄 COMMON WORKFLOWS

### Workflow 1: Fix Deployment Error
```
1. "health check"           → See what's broken
2. "fix now"                → Auto-heal issues
3. "test locally"           → Verify fix works
4. "deploy"                 → Push to production
```

### Workflow 2: Build New Feature
```
1. "build user dashboard"   → Start feature build
2. [Review plan]            → Check proposed structure
3. "✅ proceed"              → Approve and build
4. [Agent works]            → Wait for completion
5. "test locally"           → Verify it works
6. "deploy"                 → Go live
```

### Workflow 3: Debug Module Error
```
1. [See error in terminal]  → Note error message
2. "fix now"                → Try auto-heal
3. If fails: "help MODULE_NOT_FOUND"
4. [Follow suggested fix]
5. "test locally"           → Verify resolved
```

### Workflow 4: Create Component
```
1. "create ProfileCard component"
2. [Review generated code]
3. "add loading state"      → Enhance component
4. "test locally"           → See it render
5. "commit"                 → Save progress
```

### Workflow 5: Deploy with Checks
```
1. "status check"           → Verify ready
2. "build test"             → Test build
3. "type check"             → TypeScript clean
4. "lint check"             → ESLint clean
5. "deploy"                 → Push to prod
```

---

## 📂 FILE STRUCTURE REFERENCE

### Quick Paths
```
Root
├── app/                    # Next.js App Router
│   ├── (synqra)/          # Synqra routes
│   ├── (noid)/            # NØID routes
│   ├── (aurafx)/          # AuraFX routes
│   └── api/               # API routes
├── components/            # Shared components
│   ├── ui/               # UI primitives
│   └── [feature]/        # Feature components
├── lib/                   # Utilities
│   ├── utils.ts          # General utilities
│   ├── types.ts          # TypeScript types
│   └── constants.ts      # Constants
├── public/               # Static assets
├── .cursorrules          # Your automation rules
├── agents.md             # Agent definitions
└── package.json          # Dependencies
```

### Where to Create Files
| File Type | Location | Example |
|-----------|----------|---------|
| Page | `app/(product)/[route]/page.tsx` | `app/(synqra)/dashboard/page.tsx` |
| Component | `components/[feature]/` | `components/dashboard/MetricsCard.tsx` |
| API Route | `api/[feature]/route.ts` | `api/dashboard/route.ts` |
| Utility | `lib/[feature]/utils.ts` | `lib/dashboard/utils.ts` |
| Types | `lib/[feature]/types.ts` | `lib/dashboard/types.ts` |
| Style | `app/globals.css` | Global styles only |

---

## 🎨 BRAND QUICK REFERENCE

### Colors (Tailwind Classes)
```css
/* Backgrounds */
bg-zinc-950              /* Main background */
bg-zinc-900/50           /* Card background */
backdrop-blur-xl         /* Glassmorphism */

/* Text */
text-zinc-50             /* Headings */
text-zinc-300            /* Body text */
text-zinc-500            /* Muted text */

/* Accents (Product-specific) */
text-amber-500           /* Synqra gold */
text-cyan-400            /* NØID teal */
text-blue-400            /* AuraFX blue */

/* Borders */
border-zinc-800          /* Default borders */
border-amber-500         /* Active/focus */
```

### Typography
```css
/* Fonts */
font-montserrat font-bold    /* Headings */
font-inter                   /* Body text */
font-mono                    /* Code/numbers */

/* Sizes */
text-6xl                     /* Hero */
text-4xl                     /* H1 */
text-2xl                     /* H2 */
text-base                    /* Body */
text-sm                      /* Small */
```

### Animations
```css
/* Transitions */
transition-all duration-300 ease-in-out

/* Hover Effects */
hover:scale-105
hover:brightness-110
hover:opacity-80

/* Loading States */
animate-pulse
animate-spin
```

---

## ⚡ TERMINAL COMMANDS

### Development
```bash
npm run dev              # Start dev server (localhost:3000)
npm run build            # Build for production
npm run start            # Start production build
npm run lint             # Run ESLint
npm run type-check       # TypeScript check
```

### Package Management
```bash
npm install              # Install all dependencies
npm install [package]    # Add new package
npm uninstall [package]  # Remove package
npm update               # Update all packages
npm audit                # Security check
npm audit fix            # Auto-fix vulnerabilities
```

### Git Commands
```bash
git status               # Check current status
git add .                # Stage all changes
git commit -m "message"  # Commit with message
git push                 # Push to GitHub
git pull                 # Pull latest changes
git checkout -b [branch] # Create new branch
git checkout [branch]    # Switch branches
```

### File Operations
```bash
ls                       # List files
cd [folder]              # Change directory
mkdir [folder]           # Create folder
rm [file]                # Delete file
cat [file]               # View file contents
code [file]              # Open in Cursor
```

---

## 🚨 EMERGENCY FIXES

### App Won't Build
```
1. rm -rf .next
2. rm -rf node_modules package-lock.json
3. npm install
4. npm run build
```

### Module Not Found
```
1. npm install [package-name]
2. If still fails: npm install [package-name] --force
3. Restart dev server
```

### Port Already in Use
```
1. Kill process: npx kill-port 3000
2. Or change port: PORT=3001 npm run dev
```

### Git Merge Conflict
```
1. git status (see conflicted files)
2. Open files, resolve conflicts
3. git add .
4. git commit -m "fix: resolve merge conflicts"
```

### Environment Variables Not Loading
```
1. Check .env.local exists
2. Verify variable names (case-sensitive)
3. Restart dev server (Ctrl+C, then npm run dev)
4. For Railway: Add in dashboard settings
```

---

## 🤖 AGENT QUICK START

### Start Background Agent
```
1. Press Cmd/Ctrl + Shift + I
2. Type: "start [agent-name]"
3. Agent runs in background
4. Continue your work
5. Agent notifies when complete
```

### Available Agents
```
"start health_monitor"      # Continuous health checks
"start auto_healer"         # Auto-fix errors
"start feature_builder"     # Build complete features
"start deployment_manager"  # Handle deployments
"start doc_generator"       # Update documentation
"start performance_optimizer" # Speed improvements
"start security_auditor"    # Security scanning
```

### Stop Agent
```
"stop [agent-name]"
"pause [agent-name]"
```

### Check Agent Status
```
"show agents"               # List active agents
"status [agent-name]"       # Check specific agent
"show logs [agent-name]"    # View agent logs
```

---

## 📝 COMMIT MESSAGE TEMPLATES

### Feature
```
feat: add user profile page with edit capability
feat: implement real-time notifications
feat: create dashboard analytics component
```

### Fix
```
fix: resolve database connection timeout
fix: correct navigation menu on mobile
fix: handle missing environment variables
```

### Performance
```
perf: optimize image loading (40% faster)
perf: reduce bundle size by 15%
perf: lazy load chart components
```

### Documentation
```
docs: update API documentation
docs: add setup instructions for new developers
docs: update changelog for v1.2.0
```

### Refactor
```
refactor: extract utility functions to lib/
refactor: convert class component to functional
refactor: simplify authentication logic
```

---

## 🎓 PRO TIPS

### Speed Tips
1. **Use Cmd/Ctrl + P** to quickly open files (faster than clicking)
2. **Use Cmd/Ctrl + Shift + F** to find text across entire project
3. **Type trigger phrases** instead of explaining ("fix now" vs "can you help me fix this error")
4. **Let agents work in background** while you continue other tasks
5. **Create .cursorrules once**, use triggers forever

### Quality Tips
1. **Always run "type check"** before deploying
2. **Test locally first** with "test locally"
3. **Commit incrementally** (small commits > huge commits)
4. **Use descriptive commit messages** (future you will thank you)
5. **Review agent plans** before typing "✅ proceed"

### Workflow Tips
1. **Start with "health check"** when debugging
2. **Use "fix now" first** before manual debugging
3. **Build in feature branches** (never directly on main)
4. **Deploy during low-traffic hours** (minimize impact if issues)
5. **Check Railway logs** after deployment

### Learning Tips
1. **Type "help"** to see available triggers
2. **Type "examples"** to see workflow patterns
3. **Check .cursorrules** to understand automation
4. **Read agents.md** to learn about background tasks
5. **Experiment in feature branches** (safe to try things)

---

## 🔗 USEFUL LINKS

### Documentation
- Next.js Docs: https://nextjs.org/docs
- Tailwind Docs: https://tailwindcss.com/docs
- Supabase Docs: https://supabase.com/docs
- TypeScript Docs: https://www.typescriptlang.org/docs

### Project URLs
- Synqra Repo: https://github.com/Debearr/synqra-os
- Railway Dashboard: https://railway.app
- Supabase Dashboard: https://supabase.com/dashboard
- Cursor Docs: https://cursor.com/docs

### Tools
- Cursor Download: https://cursor.com
- Git Cheat Sheet: https://education.github.com/git-cheat-sheet-education.pdf
- npm Docs: https://docs.npmjs.com

---

## 📞 SUPPORT

### When Stuck
1. **Try "health check"** first
2. **Then "fix now"** to auto-heal
3. **Check this cheat sheet** for relevant command
4. **Search .cursorrules** for specific error
5. **Ask in Cursor Chat** with full error message

### Getting Help
```
"help [topic]"              # Get help on specific topic
"show example [workflow]"   # See example workflow
"debug [error-message]"     # Get debugging help
```

---

## ✅ QUICK CHECKLIST

### Before Committing
- [ ] Code runs locally (`npm run dev`)
- [ ] TypeScript passes (`npm run type-check`)
- [ ] Linter passes (`npm run lint`)
- [ ] No console.log statements
- [ ] Commit message is descriptive

### Before Deploying
- [ ] Build succeeds (`npm run build`)
- [ ] All tests pass
- [ ] No secrets in code
- [ ] .env in .gitignore
- [ ] Branch is up to date with main

### After Deploying
- [ ] Production URL loads
- [ ] Critical features work
- [ ] No 500 errors in logs
- [ ] Database connection active
- [ ] API routes responding

---

## 🎯 DAILY WORKFLOW EXAMPLE

### Morning Routine
```
1. "health check"           → Verify everything works
2. git pull                 → Get latest changes
3. npm install              → Update dependencies
4. npm run dev              → Start dev server
5. Ready to work! 🚀
```

### Feature Development
```
1. "build [feature]"        → Start new feature
2. [Work on feature]        → Code/review
3. "test locally"           → Verify works
4. git add .                → Stage changes
5. git commit               → Save progress
```

### End of Day
```
1. git status               → Check uncommitted work
2. git add .                → Stage all
3. git commit               → Commit day's work
4. git push                 → Backup to GitHub
5. "health check"           → Verify stable state
```

---

**🎉 You're ready to build with Cursor!**

**Quick Start:**
1. Copy .cursorrules to your project root
2. Copy agents.md to your project root  
3. Open Cursor, press `Cmd/Ctrl + I`
4. Type: `"health check"`
5. Build amazing things! ✨

---

**Version:** 1.0 | **Last Updated:** 2025-11-12  
**Created by:** Claude for NØID Labs  
**License:** Use freely within NØID Labs projects
