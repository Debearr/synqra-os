"""
KieRouter v2 - Cost-Optimized Multi-Model Gateway
Budget-aware routing with intelligent fallbacks for Kie.AI API
"""

import os
import time
import requests
from typing import Dict, Literal, Optional, List
from dataclasses import dataclass
from enum import Enum


class CostTier(Enum):
    """Cost tiers for budget-aware routing"""
    LOW = "low"          # <$0.001 per 1K tokens
    MEDIUM = "medium"    # ~$0.002 per 1K tokens
    HIGH = "high"        # >$0.005 per 1K tokens


class ModelName(Enum):
    """Available models via Kie.AI"""
    DEEPSEEK = "deepseek"
    NANOBANANA = "nanobanana"
    THREE_ONE = "3.1"
    VEO = "veo"


@dataclass
class ModelConfig:
    """Model configuration with cost and capability metadata"""
    name: str
    cost_tier: CostTier
    best_for: List[str]
    max_tokens: int = 4000
    timeout: int = 30


class KieRouter:
    """
    Intelligent model routing for Kie.AI with:
    - Task-based model selection
    - Budget-aware fallbacks
    - Automatic retry with degradation
    - Cost tracking
    """
    
    # Model registry with capabilities and costs
    MODELS = {
        ModelName.DEEPSEEK: ModelConfig(
            name="deepseek",
            cost_tier=CostTier.LOW,
            best_for=["trading_signal", "quantitative_analysis", "backtesting", "financial_analysis"],
            max_tokens=8000
        ),
        ModelName.NANOBANANA: ModelConfig(
            name="nanobanana",
            cost_tier=CostTier.LOW,
            best_for=["voice_script", "content_creation", "social_post", "email_copy"],
            max_tokens=4000
        ),
        ModelName.THREE_ONE: ModelConfig(
            name="3.1",
            cost_tier=CostTier.MEDIUM,
            best_for=["user_education", "general_query", "reasoning", "decision_validation"],
            max_tokens=4000
        ),
        ModelName.VEO: ModelConfig(
            name="veo",
            cost_tier=CostTier.MEDIUM,
            best_for=["visual_concept", "design_brief", "image_analysis"],
            max_tokens=2000
        )
    }
    
    # Task to model mapping
    TASK_MAP = {
        "trading_signal": ModelName.DEEPSEEK,
        "quantitative_analysis": ModelName.DEEPSEEK,
        "backtesting": ModelName.DEEPSEEK,
        "financial_analysis": ModelName.DEEPSEEK,
        
        "voice_script": ModelName.NANOBANANA,
        "content_creation": ModelName.NANOBANANA,
        "social_post": ModelName.NANOBANANA,
        "email_copy": ModelName.NANOBANANA,
        
        "user_education": ModelName.THREE_ONE,
        "general_query": ModelName.THREE_ONE,
        "reasoning": ModelName.THREE_ONE,
        "decision_validation": ModelName.THREE_ONE,
        
        "visual_concept": ModelName.VEO,
        "design_brief": ModelName.VEO,
        "image_analysis": ModelName.VEO
    }
    
    # Fallback cascade order (cheapest to most expensive)
    FALLBACK_ORDER = [
        ModelName.NANOBANANA,
        ModelName.DEEPSEEK,
        ModelName.THREE_ONE,
        ModelName.VEO
    ]
    
    def __init__(self, api_key: Optional[str] = None):
        """
        Initialize router with Kie.AI credentials
        
        Args:
            api_key: Kie.AI API key (falls back to KIE_API_KEY env var)
        """
        self.api_key = api_key or os.getenv("KIE_API_KEY")
        if not self.api_key:
            raise ValueError("KIE_API_KEY not provided or found in environment")
        
        self.base_url = "https://api.kie.ai/v1/completions"
        self.session = requests.Session()
        self.session.headers.update({
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json"
        })
        
        # Cost tracking
        self.total_requests = 0
        self.total_cost = 0.0
        self.request_log = []
    
    def route(
        self,
        task: str,
        prompt: str,
        max_budget: CostTier = CostTier.MEDIUM,
        max_tokens: int = 2000,
        temperature: float = 0.7,
        retry_attempts: int = 4
    ) -> Dict:
        """
        Route request to optimal model with budget constraints
        
        Args:
            task: Task type (e.g., "trading_signal", "user_education")
            prompt: The prompt to send to the model
            max_budget: Maximum cost tier allowed
            max_tokens: Maximum tokens in response
            temperature: Model temperature (0-1)
            retry_attempts: Number of retry attempts on failure
            
        Returns:
            Dict with 'success', 'data', 'model_used', 'cost_tier', 'fallback_used'
        """
        # Select optimal model for task
        primary_model = self._select_model(task, max_budget)
        
        # Attempt with primary model
        for attempt in range(retry_attempts):
            try:
                result = self._call_model(
                    model=primary_model,
                    prompt=prompt,
                    max_tokens=max_tokens,
                    temperature=temperature
                )
                
                # Success - return immediately
                self._log_request(task, primary_model.value, success=True, attempt=attempt+1)
                return {
                    "success": True,
                    "data": result,
                    "model_used": primary_model.value,
                    "cost_tier": self.MODELS[primary_model].cost_tier.value,
                    "fallback_used": False,
                    "attempts": attempt + 1
                }
                
            except Exception as e:
                # Log failure
                self._log_request(task, primary_model.value, success=False, attempt=attempt+1, error=str(e))
                
                # If not last attempt, wait and retry
                if attempt < retry_attempts - 1:
                    time.sleep(2 ** attempt)  # Exponential backoff
                    continue
                
                # Last attempt failed - try fallback cascade
                return self._fallback_cascade(task, prompt, max_tokens, temperature, max_budget)
        
        # Should never reach here, but just in case
        return self._emergency_response(task, prompt)
    
    def _select_model(self, task: str, max_budget: CostTier) -> ModelName:
        """Select best model for task within budget"""
        # Get primary model for task
        primary = self.TASK_MAP.get(task, ModelName.THREE_ONE)
        
        # Check if within budget
        if self._is_within_budget(primary, max_budget):
            return primary
        
        # Find cheaper alternative that can handle task
        for model in self.FALLBACK_ORDER:
            config = self.MODELS[model]
            if self._is_within_budget(model, max_budget) and task in config.best_for:
                return model
        
        # If no match, use cheapest available
        return ModelName.NANOBANANA
    
    def _is_within_budget(self, model: ModelName, max_budget: CostTier) -> bool:
        """Check if model cost tier is within budget"""
        model_cost = self.MODELS[model].cost_tier
        
        if max_budget == CostTier.LOW:
            return model_cost == CostTier.LOW
        elif max_budget == CostTier.MEDIUM:
            return model_cost in [CostTier.LOW, CostTier.MEDIUM]
        else:  # HIGH budget allows all
            return True
    
    def _call_model(
        self,
        model: ModelName,
        prompt: str,
        max_tokens: int,
        temperature: float
    ) -> Dict:
        """Make API call to Kie.AI"""
        config = self.MODELS[model]
        
        payload = {
            "model": config.name,
            "prompt": prompt,
            "max_tokens": min(max_tokens, config.max_tokens),
            "temperature": temperature
        }
        
        response = self.session.post(
            self.base_url,
            json=payload,
            timeout=config.timeout
        )
        
        response.raise_for_status()
        return response.json()
    
    def _fallback_cascade(
        self,
        task: str,
        prompt: str,
        max_tokens: int,
        temperature: float,
        max_budget: CostTier
    ) -> Dict:
        """Try all fallback models in order"""
        for model in self.FALLBACK_ORDER:
            # Skip if over budget
            if not self._is_within_budget(model, max_budget):
                continue
            
            try:
                result = self._call_model(model, prompt, max_tokens, temperature)
                self._log_request(task, model.value, success=True, fallback=True)
                
                return {
                    "success": True,
                    "data": result,
                    "model_used": model.value,
                    "cost_tier": self.MODELS[model].cost_tier.value,
                    "fallback_used": True,
                    "warning": "Primary model failed, used fallback"
                }
            except:
                continue
        
        # All fallbacks failed
        return self._emergency_response(task, prompt)
    
    def _emergency_response(self, task: str, prompt: str) -> Dict:
        """Return when all models fail"""
        self._log_request(task, "NONE", success=False, fallback=True)
        
        return {
            "success": False,
            "error": "All models unavailable",
            "model_used": None,
            "fallback_response": "Service temporarily unavailable. We've been notified and are working on it.",
            "action_required": "human_escalation",
            "task": task
        }
    
    def _log_request(
        self,
        task: str,
        model: str,
        success: bool,
        attempt: int = 1,
        fallback: bool = False,
        error: Optional[str] = None
    ):
        """Log request for monitoring and cost tracking"""
        self.total_requests += 1
        
        log_entry = {
            "timestamp": time.time(),
            "task": task,
            "model": model,
            "success": success,
            "attempt": attempt,
            "fallback": fallback,
            "error": error
        }
        
        self.request_log.append(log_entry)
        
        # Keep only last 1000 requests
        if len(self.request_log) > 1000:
            self.request_log.pop(0)
    
    def get_stats(self) -> Dict:
        """Get routing statistics"""
        if not self.request_log:
            return {"total_requests": 0}
        
        successful = sum(1 for log in self.request_log if log["success"])
        fallback_used = sum(1 for log in self.request_log if log["fallback"])
        
        model_usage = {}
        for log in self.request_log:
            model = log["model"]
            model_usage[model] = model_usage.get(model, 0) + 1
        
        return {
            "total_requests": self.total_requests,
            "success_rate": successful / len(self.request_log),
            "fallback_rate": fallback_used / len(self.request_log),
            "model_usage": model_usage,
            "recent_errors": [log for log in self.request_log[-10:] if not log["success"]]
        }


# ============================================
# UNIT TESTS
# ============================================

import unittest
from unittest.mock import Mock, patch, MagicMock


class TestKieRouter(unittest.TestCase):
    """Unit tests for KieRouter"""
    
    def setUp(self):
        """Set up test fixtures"""
        os.environ["KIE_API_KEY"] = "test_key_12345"
        self.router = KieRouter()
    
    def test_initialization_with_key(self):
        """Test router initializes with API key"""
        router = KieRouter(api_key="custom_key")
        self.assertEqual(router.api_key, "custom_key")
    
    def test_initialization_from_env(self):
        """Test router reads from environment"""
        self.assertEqual(self.router.api_key, "test_key_12345")
    
    def test_initialization_fails_without_key(self):
        """Test router raises error without API key"""
        del os.environ["KIE_API_KEY"]
        with self.assertRaises(ValueError):
            KieRouter()
        os.environ["KIE_API_KEY"] = "test_key_12345"  # Restore
    
    def test_model_selection_trading(self):
        """Test correct model selected for trading tasks"""
        model = self.router._select_model("trading_signal", CostTier.MEDIUM)
        self.assertEqual(model, ModelName.DEEPSEEK)
    
    def test_model_selection_content(self):
        """Test correct model selected for content tasks"""
        model = self.router._select_model("voice_script", CostTier.MEDIUM)
        self.assertEqual(model, ModelName.NANOBANANA)
    
    def test_model_selection_general(self):
        """Test correct model selected for general tasks"""
        model = self.router._select_model("user_education", CostTier.MEDIUM)
        self.assertEqual(model, ModelName.THREE_ONE)
    
    def test_budget_constraint_low(self):
        """Test low budget limits to cheap models"""
        model = self.router._select_model("user_education", CostTier.LOW)
        # Should downgrade from 3.1 (medium) to cheaper option
        self.assertIn(model, [ModelName.NANOBANANA, ModelName.DEEPSEEK])
    
    def test_budget_allows_expensive(self):
        """Test high budget allows any model"""
        model = self.router._select_model("visual_concept", CostTier.HIGH)
        self.assertEqual(model, ModelName.VEO)
    
    @patch('requests.Session.post')
    def test_successful_route(self, mock_post):
        """Test successful routing returns data"""
        mock_response = Mock()
        mock_response.status_code = 200
        mock_response.json.return_value = {"text": "Test response", "tokens": 100}
        mock_response.raise_for_status = Mock()
        mock_post.return_value = mock_response
        
        result = self.router.route("trading_signal", "Analyze EUR/USD")
        
        self.assertTrue(result["success"])
        self.assertEqual(result["model_used"], "deepseek")
        self.assertFalse(result["fallback_used"])
    
    @patch('requests.Session.post')
    def test_retry_on_failure(self, mock_post):
        """Test router retries on failure"""
        mock_post.side_effect = [
            Exception("Connection error"),
            Exception("Timeout"),
            Mock(status_code=200, json=lambda: {"text": "Success"}, raise_for_status=Mock())
        ]
        
        result = self.router.route("trading_signal", "Test", retry_attempts=4)
        
        # Should succeed on third attempt
        self.assertTrue(result["success"])
        self.assertEqual(result["attempts"], 3)
    
    @patch('requests.Session.post')
    def test_fallback_cascade(self, mock_post):
        """Test fallback to alternative models"""
        # First 4 attempts fail, then fallback succeeds
        mock_post.side_effect = [
            Exception("Primary failed"),
            Exception("Primary failed"),
            Exception("Primary failed"),
            Exception("Primary failed"),
            Mock(status_code=200, json=lambda: {"text": "Fallback success"}, raise_for_status=Mock())
        ]
        
        result = self.router.route("trading_signal", "Test", retry_attempts=4)
        
        self.assertTrue(result["success"])
        self.assertTrue(result["fallback_used"])
    
    @patch('requests.Session.post')
    def test_emergency_response(self, mock_post):
        """Test emergency response when all models fail"""
        mock_post.side_effect = Exception("All failed")
        
        result = self.router.route("trading_signal", "Test", retry_attempts=2)
        
        self.assertFalse(result["success"])
        self.assertEqual(result["action_required"], "human_escalation")
        self.assertIn("fallback_response", result)
    
    def test_stats_tracking(self):
        """Test statistics are tracked correctly"""
        with patch('requests.Session.post') as mock_post:
            mock_response = Mock()
            mock_response.status_code = 200
            mock_response.json.return_value = {"text": "Test"}
            mock_response.raise_for_status = Mock()
            mock_post.return_value = mock_response
            
            # Make several requests
            self.router.route("trading_signal", "Test 1")
            self.router.route("voice_script", "Test 2")
            self.router.route("user_education", "Test 3")
            
            stats = self.router.get_stats()
            
            self.assertEqual(stats["total_requests"], 3)
            self.assertEqual(stats["success_rate"], 1.0)
            self.assertIn("deepseek", stats["model_usage"])
            self.assertIn("nanobanana", stats["model_usage"])


if __name__ == "__main__":
    # Run tests
    unittest.main(argv=[''], exit=False, verbosity=2)
