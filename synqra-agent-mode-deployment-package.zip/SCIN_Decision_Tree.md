# SCIN Decision Tree
## Lumen vs LuxGrid: Who Handles What?

```
                    ┌─────────────────────┐
                    │   Issue Detected    │
                    └──────────┬──────────┘
                               │
                ┌──────────────┴──────────────┐
                │                             │
         [PERFORMANCE]                  [CONFIGURATION]
                │                             │
                ▼                             ▼
    ┌───────────────────────┐    ┌───────────────────────┐
    │  LUMEN TERRITORY      │    │  LUXGRID TERRITORY    │
    │  (Health/Learning)    │    │  (Workflow/Deploy)    │
    └───────────────────────┘    └───────────────────────┘
                │                             │
                ▼                             ▼
```

---

## LUMEN HANDLES (Diagnostics & Learning)

### Triggers:
- ⚠️ High latency (>500ms response time)
- ❌ Error rate spike (>5% failures)
- 📉 Resource exhaustion (CPU >80%, Memory >85%)
- 🔴 Service unavailable (health check fails)
- 🐌 Degraded performance (response time trending up)

### Actions:
1. **Detect** → Collect telemetry, identify anomaly pattern
2. **Diagnose** → Compare to historical baselines, classify severity
3. **Trigger** → Initiate healing workflow via LuxGrid API
4. **Learn** → Update ML model with incident + resolution pattern
5. **Verify** → Confirm fix worked, measure recovery time

### Example Scenarios:

**Scenario 1: AuraFX Signal Delay**
```
Problem: Signals taking 10s instead of <1s
Owner: LUMEN
Flow:
  1. Lumen detects latency spike
  2. Identifies bottleneck: Kie.AI timeout
  3. Triggers LuxGrid: "Switch to DeepSeek fallback"
  4. LuxGrid redeploys signal workflow with new model
  5. Lumen verifies: latency back to 0.8s
  6. Learns: "Kie.AI timeout → use DeepSeek direct"
```

**Scenario 2: Supabase Connection Drops**
```
Problem: Database queries failing
Owner: LUMEN
Flow:
  1. Lumen catches connection errors
  2. Attempts retry with exponential backoff (4 attempts)
  3. If all fail, triggers LuxGrid: "Restart Supabase client pool"
  4. LuxGrid executes service restart
  5. Lumen verifies: connections restored
```

---

## LUXGRID HANDLES (Orchestration & Deployment)

### Triggers:
- 🔧 Workflow update needed
- 📦 New automation deployment
- ⚙️ Configuration change required
- 🔄 Service restart/rollback
- 📊 Resource scaling (add replicas, upgrade tier)

### Actions:
1. **Register** → Add workflow to automation registry
2. **Deploy** → Push to n8n/Railway with environment configs
3. **Manage** → Track dependencies, validate prerequisites
4. **Optimize** → Analyze Lumen data, tune parameters
5. **Scale** → Adjust resources based on load patterns

### Example Scenarios:

**Scenario 1: New AuraFX Trading Pair**
```
Problem: User wants EUR/GBP signals added
Owner: LUXGRID
Flow:
  1. LuxGrid receives request via API
  2. Creates new n8n workflow for EUR/GBP
  3. Registers in automation_registry.json
  4. Deploys to production environment
  5. Notifies Lumen to start monitoring performance
```

**Scenario 2: Telegram Bot Update**
```
Problem: Need to add new command (/history)
Owner: LUXGRID
Flow:
  1. LuxGrid pulls latest bot code from GitHub
  2. Updates environment variables
  3. Deploys new version (blue-green deployment)
  4. Runs smoke tests
  5. Promotes to production if tests pass
```

---

## MIXED SCENARIOS (Lumen → LuxGrid → Lumen)

### Pattern: Lumen detects → LuxGrid executes → Lumen validates

**Example 1: Degraded Trading Performance**
```
┌─────────────────────────────────────────────────────┐
│ STEP 1: LUMEN DETECTION                             │
├─────────────────────────────────────────────────────┤
│ • Notices: Signal accuracy dropped from 73% to 58%  │
│ • Analysis: DeepSeek model responses changed        │
│ • Decision: Model needs retraining or replacement   │
└──────────────────┬──────────────────────────────────┘
                   │
                   ▼
┌─────────────────────────────────────────────────────┐
│ STEP 2: LUXGRID EXECUTION                           │
├─────────────────────────────────────────────────────┤
│ • Action: Deploy backup model (3.1 instead)         │
│ • Method: Update n8n workflow, redeploy             │
│ • Fallback: If 3.1 also fails, use cached signals   │
└──────────────────┬──────────────────────────────────┘
                   │
                   ▼
┌─────────────────────────────────────────────────────┐
│ STEP 3: LUMEN VERIFICATION                          │
├─────────────────────────────────────────────────────┤
│ • Monitor: New model performance for 24 hours       │
│ • Measure: Accuracy improved to 71%                 │
│ • Learn: "DeepSeek degrades under high load"        │
│ • Future: Auto-switch to 3.1 when load >80%         │
└─────────────────────────────────────────────────────┘
```

**Example 2: NØID Driver App Crashes**
```
Problem: Mobile app crashing for 15% of users
Owner: MIXED (Lumen → LuxGrid → Lumen)

LUMEN:
  • Detects crash rate spike in telemetry
  • Identifies pattern: Only on Android 12+
  • Correlates with recent dependency update
  • Recommends: Rollback to previous version

LUXGRID:
  • Executes rollback to last stable version
  • Deploys via Railway with "instant rollback" flag
  • Maintains current user data (no data loss)
  • Notifies users: "App updated, please restart"

LUMEN:
  • Verifies crash rate drops to <1%
  • Learns: "Android 12 incompatible with library X"
  • Creates rule: "Test on Android 12+ before deploy"
  • Updates CI/CD pipeline with new test requirement
```

---

## DECISION FLOWCHART

```
┌─────────────────────────────────────────────────────┐
│                  Issue Reported                     │
└──────────────────────┬──────────────────────────────┘
                       │
                       ▼
              ┌────────────────┐
              │  Is it about   │
              │  health/perf?  │
              └────┬───────┬───┘
                   │       │
             YES ──┘       └── NO
                   │           │
                   ▼           ▼
          ┌────────────┐  ┌────────────┐
          │   LUMEN    │  │  Is it a   │
          │  HANDLES   │  │  workflow  │
          │            │  │  /config?  │
          └────────────┘  └──┬─────┬───┘
                             │     │
                       YES ──┘     └── NO
                             │         │
                             ▼         ▼
                    ┌────────────┐  ┌──────────────┐
                    │  LUXGRID   │  │   COMPLEX    │
                    │  HANDLES   │  │   (Both)     │
                    │            │  │  Lumen leads │
                    └────────────┘  └──────────────┘
```

---

## QUICK REFERENCE TABLE

| Symptom | System | Primary Action | Handoff? |
|---------|--------|----------------|----------|
| High CPU usage | Lumen | Scale resources | → LuxGrid executes |
| Slow API response | Lumen | Identify bottleneck | → LuxGrid optimizes |
| Service crash | Lumen | Diagnose + restart | → LuxGrid deploys fix |
| Database errors | Lumen | Test connection, retry | → LuxGrid restarts pool |
| New feature request | LuxGrid | Design workflow | None |
| Deploy update | LuxGrid | Push to production | → Lumen monitors |
| Add trading pair | LuxGrid | Create automation | → Lumen tracks perf |
| Scale infrastructure | LuxGrid | Add resources | → Lumen validates |
| Model degradation | Lumen | Detect pattern | → LuxGrid switches model |
| Workflow optimization | Lumen | Analyze metrics | → LuxGrid refactors |

---

## INTEGRATION POINTS

### Lumen → LuxGrid API
```python
# Lumen calls LuxGrid when action required
luxgrid.trigger_healing({
    "service": "aurafx-signals",
    "action": "restart",
    "reason": "high_error_rate",
    "severity": "critical"
})
```

### LuxGrid → Lumen API
```python
# LuxGrid notifies Lumen after deployment
lumen.start_monitoring({
    "service": "noid-driver-app",
    "version": "v2.1.3",
    "metrics": ["crash_rate", "latency", "battery_usage"],
    "baseline_period": "24h"
})
```

### Shared Context (Supabase)
```sql
-- Both systems log to shared incident table
CREATE TABLE scin_incidents (
    id UUID PRIMARY KEY,
    detected_by TEXT, -- 'lumen' or 'luxgrid'
    handled_by TEXT,
    service_name TEXT,
    issue_type TEXT,
    resolution TEXT,
    resolved_at TIMESTAMP,
    learned_pattern JSONB
);
```

---

## BOUNDARIES (Critical Rules)

### ❌ LUMEN NEVER:
- Deploys code directly
- Modifies workflow configurations
- Makes infrastructure scaling decisions
- Touches production databases (read-only access)

### ❌ LUXGRID NEVER:
- Makes health/performance judgments
- Learns from incidents automatically
- Decides when to trigger healing
- Analyzes telemetry patterns

### ✅ BOTH COLLABORATE ON:
- Incident response (Lumen detects → LuxGrid executes)
- Optimization (Lumen recommends → LuxGrid implements)
- Validation (LuxGrid deploys → Lumen verifies)
- Continuous improvement (shared incident database)

---

## EMERGENCY ESCALATION

### When to Escalate to Humans:

**From Lumen:**
- All 4 healing attempts failed
- Data loss detected
- Security breach suspected
- Unknown error pattern (no historical match)

**From LuxGrid:**
- Deployment failed 3 times
- Dependency conflict unresolvable
- Customer data migration required
- Compliance/legal review needed

**Escalation Flow:**
```
1. SCIN attempts auto-resolution (Lumen → LuxGrid loop)
2. If unresolved after 15 minutes → Page on-call engineer
3. Log full diagnostic report to Slack
4. Create incident ticket in Linear
5. Activate degraded mode (fallback services)
```

---

## KEY TAKEAWAY

**Lumen** = Doctor (diagnoses problems, learns from history)  
**LuxGrid** = Surgeon (executes fixes, deploys solutions)  
**Together** = Self-healing system that gets smarter over time

**Rule of thumb:**  
If it's about *"something is wrong"* → **Lumen**  
If it's about *"change something"* → **LuxGrid**  
If it's both → **Lumen leads, LuxGrid executes**
